<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Fira+Sans:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Geologica:wght@100;300&family=Lato&family=Open+Sans&family=Poppins&family=Roboto&display=swap"
        rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
    <title>{{ setting('site_name') }}</title>
    <link href="{{ asset('public/userpanel') }}/asset/css/style.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.0/css/toastr.css" rel="stylesheet" />
    <link rel="shortcut icon" type="image/x-icon" href="{{ env('ADMIN_URL') . 'storage/app/' . setting('logo') }}">
    <style>
        /*::-webkit-scrollbar {*/
        /*    display: none;*/
        /*}*/

        /* #fieldsContainer{
            display: none;
        } */
    </style>
</head>

<body>
    <header class="header-bg ">

    </header>

    <nav class="navbar sticky-top navbar-expand-lg navbar-light bg-white">
        <div class="container">
            <a class="navbar-brand" href="{{ route('dashboard') }}">
                <img src="{{ asset('public/userpanel') }}/asset/images/logo.png" alt="">
            </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight"
                aria-controls="offcanvasRight" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasRight"
                aria-labelledby="offcanvasRightLabel">
                <div class="offcanvas-header">

                    <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas"
                        aria-label="Close"></button>
                </div>

            </div>
            <div class="text-end d-none d-md-block">
                <a href="#" class="btn-btn-header">
                    <span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="19" viewBox="0 0 18 19"
                            fill="none">
                            <path
                                d="M9 0C8.01109 0 7.04439 0.293245 6.22215 0.842652C5.3999 1.39206 4.75904 2.17295 4.3806 3.08658C4.00216 4.00021 3.90315 5.00555 4.09607 5.97545C4.289 6.94536 4.7652 7.83627 5.46447 8.53553C6.16373 9.2348 7.05464 9.711 8.02455 9.90393C8.99445 10.0969 9.99979 9.99784 10.9134 9.6194C11.827 9.24096 12.6079 8.6001 13.1573 7.77785C13.7068 6.95561 14 5.98891 14 5C14 3.67392 13.4732 2.40215 12.5355 1.46447C11.5979 0.526784 10.3261 0 9 0ZM9 8C8.40666 8 7.82664 7.82405 7.33329 7.49441C6.83994 7.16476 6.45542 6.69623 6.22836 6.14805C6.0013 5.59987 5.94189 4.99667 6.05764 4.41473C6.1734 3.83279 6.45912 3.29824 6.87868 2.87868C7.29824 2.45912 7.83279 2.1734 8.41473 2.05764C8.99667 1.94189 9.59987 2.0013 10.1481 2.22836C10.6962 2.45542 11.1648 2.83994 11.4944 3.33329C11.8241 3.82664 12 4.40666 12 5C12 5.79565 11.6839 6.55871 11.1213 7.12132C10.5587 7.68393 9.79565 8 9 8ZM18 19V18C18 16.1435 17.2625 14.363 15.9497 13.0503C14.637 11.7375 12.8565 11 11 11H7C5.14348 11 3.36301 11.7375 2.05025 13.0503C0.737498 14.363 0 16.1435 0 18V19H2V18C2 16.6739 2.52678 15.4021 3.46447 14.4645C4.40215 13.5268 5.67392 13 7 13H11C12.3261 13 13.5979 13.5268 14.5355 14.4645C15.4732 15.4021 16 16.6739 16 18V19H18Z"
                                fill="black" />
                        </svg> &nbsp; WELCOME <span class="text-uppercase">

                            {{ $data->first_name }}
                            {{ $data->last_name }}

                        </span>
                    </span>
                </a>
            </div>
        </div>
    </nav>

    <div class="wrap mt-5 mb-5">
        <div class="container">
            <div class="col-12">
                <div class="row">
                    <div class="col-md-8 col-12 mx-auto d-block">
                        <h1 class="text-center">REGISTRATION FORM</h1>

                        <form action="{{ route('registrationSubmit') }}" method="POST" enctype="multipart/form-data">
                            @csrf
                            <input type="hidden" name="email" value="{{ $data->email }}">
                            <div class="row">
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">First Name*</label>
                                    <input type="text" name="first_name" required value="{{ $data->first_name }}"
                                        placeholder="Full Name" class="form-control" id="">
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Last Name*</label>
                                    <input type="text" name="last_name" required value="{{ $data->last_name }}"
                                        placeholder="Last Name" class="form-control" id="">
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Phone Number*</label>
                                    <input type="text" name="phone" required value="{{ $data->phone }}"
                                        placeholder="" class="form-control" id="">
                                </div>

                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Choose Your Expedition</label>
                                    <select name="letest_trip" class="w-100 form-control" id="" required>
                                        <option value="">—Please choose an option—</option>
                                        @foreach ($trip as $trips)
                                            <option
                                                @if (request()->trip_id == $trips->id) value="{{ request()->trip_id }}" selected @else value="{{ $trips->id }}" @endif>
                                                {{ $trips->name }}</option>
                                        @endforeach


                                    </select>
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">E-mail*</label>
                                    <input type="text" name="" value="{{ $data->email }}" readonly
                                        placeholder="" class="form-control" id="">
                                </div>
                                @php
                                    $contry = allCountry();
                                @endphp
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Country</label>
                                    <select name="country" id="" class="form-control"
                                        onchange="getState(this.value)">
                                        <option>Select Country</option>
                                        @foreach ($contry as $contrys)
                                            <option
                                                @if (isset($data->country) && $contrys->name ==$data->country) value="{{ $data->country }}" selected @else value="{{ $contrys->name }}" @endif>
                                                {{ $contrys->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">State</label>
                                    <select class="form-select" name="state" id="state">
                                        @if ($data->state))
                                            <option value="{{ $data->state }}" selected>
                                                {{ $data->state }}
                                            </option>
                                        @endif
                                    </select>
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">City</label>
                                    <input type="text" name="city" value="{{ $data->city }}" placeholder=""
                                        class="form-control" id="">
                                </div>
                                <div class="col-md-12 col-12 my-2">
                                    <label for="">Pincode</label>
                                    <input type="text" name="pincode" value="{{ $data->pincode }}"
                                        placeholder="" class="form-control" id="">
                                </div>
                                <div class="col-md-12 col-12 my-2">
                                    <label for="">Address</label>
                                    <textarea name="address" id="" cols="10" rows="3" class="form-control">{{ $data->address }}</textarea>
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Date Of Birth *</label>
                                    <input type="date" name="dob" required value="{{ $data->dob }}"
                                        class="form-control" id="">
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Profession *</label>
                                    <input type="text" name="profession" required value="{{ $data->profession }}"
                                        class="form-control" id="">
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Blood Group *</label>
                                    <select name="blood_group" required class="w-100 form-control" id=""
                                        required>
                                        <option value="">—Please choose an option—</option>
                                        <option @if ($data->blood_group == 'a+') selected @endif value="a+">A+
                                        </option>
                                        <option @if ($data->blood_group == 'a-') selected @endif value="a-">A-
                                        </option>
                                        <option @if ($data->blood_group == 'b+') selected @endif value="b+">B+
                                        </option>
                                        <option @if ($data->blood_group == 'b-') selected @endif value="b-">B-
                                        </option>
                                        <option @if ($data->blood_group == 'o+') selected @endif value="o+">O+
                                        </option>
                                        <option @if ($data->blood_group == 'o-') selected @endif value="o-">O-
                                        </option>
                                        <option @if ($data->blood_group == 'ab+') selected @endif value="ab+">AB+
                                        </option>
                                        <option @if ($data->blood_group == 'ab-') selected @endif value="ab-">AB-
                                        </option>

                                    </select>
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Meal Preference *</label>
                                    <input type="text" required name="meal_preference"
                                        value="{{ $data->meal_preference }}" placeholder="" class="form-control"
                                        id="">
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Choose T-Shirt Size *</label>
                                    <select name="t_size" required class="w-100 form-control" id=""
                                        required>
                                        <option value="">—Please choose an option—</option>
                                        <option @if ($data->t_size == 'Kids') selected @endif value="Kids">Kids
                                        </option>
                                        <option @if ($data->t_size == 'XS') selected @endif value="XS">XS
                                        </option>
                                        <option @if ($data->t_size == 'S') selected @endif value="S">S
                                        </option>
                                        <option @if ($data->t_size == 'M') selected @endif value="M">M
                                        </option>
                                        <option @if ($data->t_size == 'L') selected @endif value="L">L
                                        </option>
                                        <option @if ($data->t_size == '2XL') selected @endif value="2XL">2XL
                                        </option>
                                        <option @if ($data->t_size == '3XL') selected @endif value="3XL">3XL
                                        </option>


                                    </select>
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Medical Condition if any *</label>
                                    <input type="text" required name="medical_condition"
                                        value="{{ $data->medical_condition }}" placeholder="" class="form-control"
                                        id="">
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Emergency Contact Name *</label>
                                    <input type="text" required name="emg_name" value="{{ $data->emg_name }}"
                                        placeholder="" class="form-control" id="">
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Emergency Contact Number </label>
                                    <input type="text" name="emg_contact" value="{{ $data->emg_contact }}"
                                        placeholder="" class="form-control" id="">
                                </div>
                                <div class="col-md-12 col-12 my-2">
                                    <label for="">Tell us something about yourself in 20 words</label>
                                    <textarea name="something" id="" cols="10" rows="3" class="form-control">{{ $data->something }}</textarea>
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Have you done a road trip before? If yes, where? *</label>
                                    <input type="text" name="have_road_trip" required
                                        value="{{ $data->have_road_trip }}" placeholder="" class="form-control"
                                        id="">
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Most Thrilling Experience of your life? *</label>
                                    <input type="text" name="thrilling_exp" required
                                        value="{{ $data->thrilling_exp }}" placeholder="" class="form-control"
                                        id="">
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Three Travel essentials for Road Trips? *</label>
                                    <input type="text" name="three_travel" required
                                        value="{{ $data->three_travel }}" placeholder="" class="form-control"
                                        id="">
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Three places in your bucket list? *</label>
                                    <input type="text" name="three_place" required
                                        value="{{ $data->three_place }}" placeholder="" class="form-control"
                                        id="">
                                </div>

                                <div class="col-md-12 col-12 my-2">
                                    <label for="">Vaccination *</label>
                                    <select name="vaccination" class="w-100 form-control" id="" required>
                                        <option value="">—Please choose an option—</option>
                                        <option @if ($data->vaccination == 'Singel') selected @endif value="Singel">
                                            Singel</option>
                                        <option @if ($data->vaccination == 'Double') selected @endif value="Double">
                                            Double</option>
                                        <option @if ($data->vaccination == 'None') selected @endif value="None">None
                                        </option>


                                    </select>
                                </div>

                                {{-- image --}}
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Passport Upload (Front)</label><br>
                                    @if (isset($data->passport_front))
                                        <img src="{{ asset('storage/app/' . $data->passport_front) }}" width="100px"
                                            alt="">
                                    @endif
                                    <input type="file" name="passport_front" placeholder="" class="form-control"
                                        id="">
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Passport Upload (Back)</label><br>
                                    @if (isset($data->passport_back))
                                        <img src="{{ asset('storage/app/' . $data->passport_back) }}" width="100px"
                                            alt="">
                                    @endif
                                    <input type="file" name="passport_back" placeholder="" class="form-control"
                                        id="">
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Pan Card / GST Certificate (For Billing Purpose)</label><br>
                                    @if (isset($data->pan_gst))
                                        <img src="{{ asset('storage/app/' . $data->pan_gst) }}" width="100px"
                                            alt="">
                                    @endif
                                    <input type="file" name="pan_gst" placeholder="" class="form-control"
                                        id="">
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Aadhaar Card Upload</label><br>
                                    @if (isset($data->adhar_card))
                                        <img src="{{ asset('storage/app/' . $data->adhar_card) }}" width="100px"
                                            alt="">
                                    @endif
                                    <input type="file" name="adhar_card" placeholder="" class="form-control"
                                        id="">
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Driving License Upload</label><br>
                                    @if (isset($data->driving))
                                        <img src="{{ asset('storage/app/' . $data->driving) }}" width="100px"
                                            alt="">
                                    @endif
                                    <input type="file" name="driving" placeholder="" class="form-control"
                                        id="">
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Profile Picture Upload (Candid) * ( Max Size:3mb
                                        )</label><br>
                                    @if (isset($data->profile))
                                        <img src="{{ asset('storage/app/' . $data->profile) }}" width="100px"
                                            alt="">
                                    @endif
                                    <input type="file" name="profile" placeholder="" class="form-control"
                                        id="">
                                </div>

                                <div class="col-12 mt-4">
                                    <h3>Extra Documents</h3>
                                    <hr/>
                                    <div class="form-repeater">
                                        <div data-repeater-list="group-a">
                                            <div data-repeater-item>
                                                <div class="row">
                                                    @if (count($extra) > 0)
                                                        <div id="editField">

                                                            @foreach ($extra as $data)
                                                                <input type="hidden" name="id[]"
                                                                    value="{{ $data->id }}">
                                                                <div class="row field-edit"
                                                                    id="docImage{{ $data->id }}">
                                                                    <div class="col-md-4 col-12 my-2">
                                                                        <label for="">Document Name</label>
                                                                        <input type="text" name="title[]"
                                                                            value="{{ $data->title }}"
                                                                            placeholder="" class="form-control"
                                                                            id="">
                                                                    </div>

                                                                    <div class="col-md-4 col-12 my-2">
                                                                        <label for="">Image</label><br>

                                                                        <input type="file" name="image[]"
                                                                            placeholder=""
                                                                            class="form-control multiple-img"
                                                                            id="">
                                                                    </div>
                                                                    <div class="col-md-2 col-12">
                                                                        @if (isset($extra))
                                                                            <img src="{{ asset('storage/app/' . $data->image) }}"
                                                                                alt="" width="100px">
                                                                        @endif
                                                                    </div>
                                                                    <div class="col-md-2 d-flex col-12">
                                                                        <a href="javaScript:void(0)"
                                                                            onclick="removeFieldEdit({{ $data->id }})"
                                                                            class="btn btn-danger"
                                                                            style="height: 37px;margin-top:33px;width:100%">
                                                                            Remove</a>

                                                                    </div>
                                                                </div>
                                                            @endforeach
                                                        </div>
                                                    @endif
                                                </div>

                                            </div>
                                        </div>

                                    </div>

                                </div>
                                <div class="col-12 mb-4">

                                    <div class="form-repeater">
                                        <div data-repeater-list="group-a">
                                            <div data-repeater-item>
                                                <div class="row">

                                                    <div id="fieldsContainer">

                                                        <div class="row field">
                                                            <div class="col-md-5 col-12 my-2">
                                                                <label for="">Document Name</label>
                                                                <input type="text" name="title[]" value=""
                                                                    placeholder="" class="form-control"
                                                                    id="">
                                                            </div>

                                                            <div class="col-md-5 col-12 my-2">
                                                                <label for="">Image</label><br>

                                                                <input type="file" name="image[]" placeholder=""
                                                                    class="form-control multiple-img" id="">
                                                            </div>
                                                            <div class="col-2 d-flex">
                                                                <a href="javaScript:void(0)" onclick="removeField(0)"
                                                                    class="btn btn-danger"
                                                                    style="height: 37px;margin-top:33px;width:100%">
                                                                    Remove</a>

                                                            </div>
                                                        </div>


                                                    </div>
                                                    <div class="text-end">
                                                        <a href="javaScript:void(0)" onclick="addNewField()"
                                                            class="btn btn-success mx-1"> Add
                                                        </a>
                                                    </div>


                                                </div>

                                            </div>
                                        </div>

                                    </div>

                                </div>

                                <div class="col-md-12 col-12 my-2 mt-3">
                                    <label for="">Terms and Conditions*</label>
                                    <div class="border border-secondary p-3 mt-1 rounded"
                                        style="max-height:250px;overflow-y:scroll;">
                                        {!! setting('terms_condition') !!}
                                    </div>
                                </div>
                                <div class="col-md-12 col-12 my-2">

                                    <input type="checkbox" name="" id="" required> Yes, I have read
                                    and agree
                                    to the Terms of Service.
                                </div>

                            </div>
                            <button class="button rounded-pill p-2 px-5 mt-2">Submit</button>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script>
        // var fieldCounter = 0;

        function addNewField() {
            var existingField = document.querySelector('.field');
            var newField = existingField.cloneNode(true);
            // var inputs = newField.querySelectorAll('input, textarea, select');
            // inputs.forEach(function(input) {
            //     input.value = ''; // Clear the value
            // });
            // fieldCounter++;

            // Get the cloned input element and update its name attribute
            var clonedInput = newField.querySelector('.multiple-img');
            clonedInput.name = "image[]";

            document.getElementById("fieldsContainer").appendChild(newField);
            // $('#fieldsContainer').css("display","block")
        }

        function removeField(id) {
            var fields = document.querySelectorAll('.field');
            if (fields.length > 0) {
                // Remove the last field
                fields[fields.length - 1].remove();
            } else {
                alert("At least one field must be present.");
            }
            // $.ajax({
            //     url:"{{ route('removeImage') }}",
            //     type:'post',
            //     data:[
            //         id = id
            //     ],
            //     token:"{{ csrf_token() }}",

            //     success: function(responce) {
            //     if (responce == 1) {
            //         // alert(responce);
            //         $('#docImage'+id).remove();
            //         setTimeout(function() {
            //             toastr['success'](

            //                 {
            //                     closeButton: true,
            //                     tapToDismiss: true,
            //                     // rtl: isRtl
            //                 }
            //             );

            //         }, 2000);
            //         toastr.success("Document Remove Successfully");
            //     } 

            // }
            // });
        }

        function removeFieldEdit(id) {
            // alert('hii');
            var fields = document.querySelectorAll('.field-edit');
            // if (fields.length > 0) {
            //     // Remove the last field
            //     fields[fields.length - 1].remove();
            // } else {
            //     alert("At least one field must be present.");
            // }
            $.ajax({
                url: "{{ route('removeImage') }}",
                type: 'post',
                data: {
                    id: id,
                    _token: "{{ csrf_token() }}",
                },

                success: function(responce) {
                    if (responce == 1) {
                        // alert(responce);
                        $('#docImage' + id).remove();
                        setTimeout(function() {
                            toastr['success'](

                                {
                                    closeButton: true,
                                    tapToDismiss: true,
                                    // rtl: isRtl
                                }
                            );

                        }, 2000);
                        toastr.success("Document Remove Successfully");
                    }

                }
            });
        }
    </script>
    <script>
        function getState(value){
            $.ajax({
                url:"{{route('getState')}}",
                type:"post",
                data:{
                    value:value,
                    _token:"{{csrf_token()}}"
                },
               success:function(responce){
                    $('#state').html(responce);
                    $('#state').prop("disabled", false);
               }
            });
        }
    </script>

</body>

</html>
