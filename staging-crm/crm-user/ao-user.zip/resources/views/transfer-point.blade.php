@extends('layouts.userlayout.index')
<style>
    th {
        white-space: nowrap;
    }
    td {
        white-space:nowrap;
    }
</style>
@section('container')

<div class="col-md-10 col-12">
    <div class="border-shadow mb-4">
        <div class="card">
            <div class="card-header bg-white information">
                @include('layouts.userlayout.card-header')
            </div>
            <div class="card-body">
                <h6 class="text fw-bold mb-3">Transfer Your Points</h6>

                <div class="card border-shadow pb-4 ">
                    <div class="text-center mt-4 total-earning-card">
                        {{-- <div class="bg-white shadows rounded p-2 px-4 information-trip mx-3">
                            <span class="text"><span class="curent-tier">You Have </span> total:</span>
                            <img src="{{asset('public/userpanel')}}/asset/images/star.svg" alt="">
                            <span class="text fw-bold information-trip-count">{{Auth::user()->points}}</span>
                            <small>Points</small>
                            <small class="ps-4">Expiring on: 26th Jan, 2023</small>
                        </div> --}}
                          <span class=" rounded shadows bg-white p-3 ">

                                <span class="font-size-14 font-size-mobile-14 fw-bold text"> You Have Total</span>
                                &nbsp; <img src="{{ asset('public/userpanel') }}/asset/images/star.svg" alt="">
                                <span class="fw-bold font-size-20 font-size-mobile-20">{{ Auth::user()->points }}</span>
                                <small class="font-size-10 font-size-mobile-10">Points</small>
                                &nbsp; <small class="font-size-9 font-size-mobile-9">Expiring on: 26th Jan, 2023</small>

                            </span>
                    </div>
                    <div class="text-center mt-4">
                        <small class="fw-bold green background-3 rounded p-2 px-3 point-text font-size-12">Your total points are {{Auth::user()->points}}, which is equal to Rs. {{Auth::user()->points}} (1 point = Rs. 1)</small>
                    </div>

                    <div class="col-md-6 mx-auto d-block mt-3">
                        <div class="row px-2">
                            <div class="col-md-6 col-12 ">
                                <div class="background-4 rounded p-2 text-center text-white total-earnd">

                                    <span class="fw-bold">Total Recieved</span> <img src="{{asset('public/userpanel')}}/asset/images/star.svg"> &nbsp; {{$reciver}} <small>Points</small>
                                </div>
                            </div>

                            <div class="col-md-6 col-12 earn-card">
                                <div class="background-7 rounded p-2 text-center text-white total-earnd">

                                    <span class="fw-bold">Total Transferred</span> <img src="{{asset('public/userpanel')}}/asset/images/star.svg"> &nbsp; {{$transfer}} <small>Points</small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="container mt-3">
                        <div class="row">
                            <div class="col-12 col-md-4 redeem-form">
                                <h6 class="text fw-bold">Transfer your points</h6>
                                <form action="{{route('transferCoin')}}" method="post">
                                    @csrf
                                    <label for="" class="mt-3">Enter email id</label><br>
                                    <input type="text" name="email" class="form-control" placeholder="saleem@mail.com">

                                    <label for="" class="mt-3">Enter points to transfer</label><br>
                                    <input type="text" name="points" class="form-control" placeholder="500">

                                    <button class="button mt-3 px-4 p-2 ">Transfer Points</button>
                                </form>


                            </div>
                            <div class="col-12 col-md-1">

                            </div>
                            <div class="col-12 col-md-7">
                                <div class="background-2 rounded p-2">
                                    {!!setting('transfer_points')!!}
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="px-3 mt-5">
                        <h6 class="text fw-bold">Recent Transactions</h6>

                        <div class="col-12 table-responsive">
                            @if (count($data)>0)
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col">Received/Sent Date</th>
                                        <th scope="col">User Send/Recieve to</th>
                                        <th scope="col">Expiry Date</th>
                                        <th scope="col">CR/DR</th>
                                        <th scope="col">Balance</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    
                                        @foreach ($data as $datas)
                                            
                                            <tr>
                                                <td>{{(date('M d Y',strtotime($datas->created_at)))}} - @if($datas->trans_type == 'Credit') Recieved @else Sent @endif</td>
                                                <td>Self</td>
                                                <td>{{date('M d Y',strtotime($datas->expiry_date))}}</td>
                                                <td><span class="@if($datas->trans_type == 'Credit') background-3 green @else background-6 red @endif p-1 rounded fw-bold">@if($datas->trans_type == 'Credit')+ @else - @endif {{$datas->trans_amt}}</span></td>
                                                <th>{{$datas->balance}}</th>
                                            </tr>
                                        @endforeach

                                    

                                </tbody>
                            </table>
                            @else
                                    <div class="text-center">
                                        <h6>No Data Found</h6>
                                    </div>
                                    @endif
                                    
                        </div>
                    </div>

                </div>

            </div>
            <!-- important note -->
            <div class=" px-4">
@include('imp')

            </div>

           
        </div>
    </div>
</div>

@endsection