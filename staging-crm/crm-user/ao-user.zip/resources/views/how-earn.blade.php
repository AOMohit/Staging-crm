@extends('layouts.userlayout.index')
@section('container')

<div class="col-md-10 col-12">
    <div class="border-shadow mb-4">
        <div class="card">
            <div class="card-header bg-white information">
               
                @include('layouts.userlayout.card-header')
                
            </div>
            <div class="card-body">
                <h6 class="text fw-bold mb-3">How to Earn Points</h6>

                <div class="card border-shadow pb-4 ">
                    <div class="text-center mt-4 total-earning-card">
                            
                            <span class=" rounded shadows bg-white p-3 ">

                                <span class="font-size-14 font-size-mobile-14 fw-bold text"> You Have Total</span>
                                &nbsp; <img src="{{ asset('public/userpanel') }}/asset/images/star.svg" alt="">
                                <span class="fw-bold font-size-20 font-size-mobile-20">{{ Auth::user()->points }}</span>
                                <small class="font-size-10 font-size-mobile-10">Points</small>
                                &nbsp; <small class="font-size-9 font-size-mobile-9">Expiring on: 26th Jan, 2023</small>

                            </span>

                    </div>
                    <div class="text-center mt-4">
                        <small class="fw-bold green background-3 rounded p-2 px-3 point-text">Your total points are 5000, which is equal to Rs. 5000 (1 point = Rs. 1)</small>
                    </div>

                    <div class="p-4">
                        <h6 class="text fw-bold">{!!setting('how_to_earn_title')!!}</h6>
                                                  {!!setting('how_to_earn')!!}

                    </div>

                </div>

            </div>
            <div class=" px-4">

                @include('imp')
            </div>
        </div>
    </div>
</div>

@endsection