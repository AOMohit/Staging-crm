@extends('layouts.userlayout.index')
<style>
    th {
        white-space: nowrap;
    }
    td {
        white-space:nowrap;
    }
</style>
@section('container')


    <div class="col-md-10 col-12">
        <div class="border-shadow mb-4">
            <div class="card">
                <div class="card-header bg-white information">
                    @include('layouts.userlayout.card-header')
                </div>
                <div class="card-body">
                    <h6 class="text fw-bold mb-3">How to Earn Points</h6>

                    <div class="card border-shadow pb-4 ">
                        <div class="text-center mt-4 total-earning-card">
                            {{-- <div class="bg-white shadows rounded p-2 px-4 information-trip mx-4">
                            <span class="text"> <span class="curent-tier"> You have</span> total:</span>
                            <img src="{{asset('public/userpanel')}}/asset/images/star.svg" alt="">
                            <span class="text fw-bold information-trip-count">{{Auth::user()->points}}</span>
                            <small>Points</small>
                            <small class="expiring-point">Expiring on: 26th Jan, 2023</small>
                        </div> --}}
                            <span class=" rounded shadows bg-white p-3 ">

                                <span class="font-size-14 font-size-mobile-14 fw-bold text"> You Have Total</span>
                                &nbsp; <img src="{{ asset('public/userpanel') }}/asset/images/star.svg" alt="">
                                <span class="fw-bold font-size-20 font-size-mobile-20">{{ Auth::user()->points }}</span>
                                <small class="font-size-10 font-size-mobile-10">Points</small>
                                &nbsp; <small class="font-size-9 font-size-mobile-9">Expiring on: 26th Jan, 2023</small>

                            </span>

                        </div>
                        <div class="text-center mt-4">
                            <small class="fw-bold green background-3 rounded p-2 px-3 point-text font-size-12">Your total
                                points are {{ Auth::user()->points }}, which is equal to Rs. {{ Auth::user()->points }} (1
                                point = Rs. 1)</small>
                        </div>

                        <div class="col-md-6 col-12 mx-auto d-block mt-3 ">
                            <div class="row px-2">
                                <div class="col-md-6 col-12 ">
                                    <div class="background-4 rounded p-3 text-center text-white  total-earnd">

                                        <span class="fw-bold">Total Earned</span> <img
                                            src="{{ asset('public/userpanel') }}/asset/images/star.svg">
                                        {{ Auth::user()->points }} <small>Points</small>
                                    </div>
                                </div>

                                <div class="col-md-6 col-12 earn-card">
                                    <div class="background-5 rounded p-3 text-center text-white  total-earnd">

                                        <span class="fw-bold">Total Redeemed</span> <img
                                            src="{{ asset('public/userpanel') }}/asset/images/star.svg"> {{ $redeem }}
                                        <small>Points</small>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="px-3 mt-4">
                            <h6 class="text fw-bold">Recent Transactions</h6>

                            <div class="col-12 table-responsive">
                                {{-- @dd($point) --}}
                                @if (count($point) > 0)
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th scope="col">Earned Date</th>
                                                <th scope="col">Reason</th>
                                                <th scope="col">Trip Name</th>
                                                <th scope="col">Trip Cost</th>
                                                <th scope="col">Expiry Date</th>
                                                <th scope="col">CR/DR</th>
                                                <th scope="col">Balance</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($point as $allpoint)
                                                <tr>
                                                    <td>{{ date('d M, Y', strtotime($allpoint->created_at)) }}</td>
                                                    <td>{{ $allpoint->reason }}</td>
                                                    <td>{{ $allpoint->trip_name }}</td>
                                                    <td>₹ {{ number_format($allpoint->cost) }}</td>
                                                    <td>{{ date('d M, Y', strtotime($allpoint->expiry_date)) }}</td>
                                                    <td><span
                                                            class="@if ($allpoint->trans_type == 'Cr') background-3 green @else background-6 red @endif p-1 rounded fw-bold">
                                                            @if ($allpoint->trans_type == 'Cr')
                                                                +
                                                            @else
                                                                -
                                                            @endif {{ $allpoint->trans_amt }}
                                                        </span></td>

                                                    <th>₹{{ $allpoint->balance }}</th>
                                                </tr>
                                            @endforeach

                                        </tbody>
                                    </table>
                                @else
                                    <div class="text-center">
                                        <h6>No Data Found</h6>
                                    </div>
                                @endif
                            </div>
                        </div>

                    </div>

                </div>
                <div class=" px-4">
                    @include('imp')
                </div>

            </div>
        </div>
    </div>

@endsection
