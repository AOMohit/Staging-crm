
<style>
    th {
        white-space: nowrap;
    }
    td {
        white-space:nowrap;
    }
</style>
<?php $__env->startSection('container'); ?>


    <div class="col-md-10 col-12">
        <div class="border-shadow mb-4">
            <div class="card">
                <div class="card-header bg-white information">
                    <?php echo $__env->make('layouts.userlayout.card-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="card-body">
                    <h6 class="text fw-bold mb-3">How to Earn Points</h6>

                    <div class="card border-shadow pb-4 ">
                        <div class="text-center mt-4 total-earning-card">
                            
                            <span class=" rounded shadows bg-white p-3 ">

                                <span class="font-size-14 font-size-mobile-14 fw-bold text"> You Have Total</span>
                                &nbsp; <img src="<?php echo e(asset('public/userpanel')); ?>/asset/images/star.svg" alt="">
                                <span class="fw-bold font-size-20 font-size-mobile-20"><?php echo e(Auth::user()->points); ?></span>
                                <small class="font-size-10 font-size-mobile-10">Points</small>
                                &nbsp; <small class="font-size-9 font-size-mobile-9">Expiring on: 26th Jan, 2023</small>

                            </span>

                        </div>
                        <div class="text-center mt-4">
                            <small class="fw-bold green background-3 rounded p-2 px-3 point-text font-size-12">Your total
                                points are <?php echo e(Auth::user()->points); ?>, which is equal to Rs. <?php echo e(Auth::user()->points); ?> (1
                                point = Rs. 1)</small>
                        </div>

                        <div class="col-md-6 col-12 mx-auto d-block mt-3 ">
                            <div class="row px-2">
                                <div class="col-md-6 col-12 ">
                                    <div class="background-4 rounded p-3 text-center text-white  total-earnd">

                                        <span class="fw-bold">Total Earned</span> <img
                                            src="<?php echo e(asset('public/userpanel')); ?>/asset/images/star.svg">
                                        <?php echo e(Auth::user()->points); ?> <small>Points</small>
                                    </div>
                                </div>

                                <div class="col-md-6 col-12 earn-card">
                                    <div class="background-5 rounded p-3 text-center text-white  total-earnd">

                                        <span class="fw-bold">Total Redeemed</span> <img
                                            src="<?php echo e(asset('public/userpanel')); ?>/asset/images/star.svg"> <?php echo e($redeem); ?>

                                        <small>Points</small>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="px-3 mt-4">
                            <h6 class="text fw-bold">Recent Transactions</h6>

                            <div class="col-12 table-responsive">
                                
                                <?php if(count($point) > 0): ?>
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th scope="col">Earned Date</th>
                                                <th scope="col">Reason</th>
                                                <th scope="col">Trip Name</th>
                                                <th scope="col">Trip Cost</th>
                                                <th scope="col">Expiry Date</th>
                                                <th scope="col">CR/DR</th>
                                                <th scope="col">Balance</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $point; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allpoint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e(date('d M, Y', strtotime($allpoint->created_at))); ?></td>
                                                    <td><?php echo e($allpoint->reason); ?></td>
                                                    <td><?php echo e($allpoint->trip_name); ?></td>
                                                    <td>₹ <?php echo e(number_format($allpoint->cost)); ?></td>
                                                    <td><?php echo e(date('d M, Y', strtotime($allpoint->expiry_date))); ?></td>
                                                    <td><span
                                                            class="<?php if($allpoint->trans_type == 'Cr'): ?> background-3 green <?php else: ?> background-6 red <?php endif; ?> p-1 rounded fw-bold">
                                                            <?php if($allpoint->trans_type == 'Cr'): ?>
                                                                +
                                                            <?php else: ?>
                                                                -
                                                            <?php endif; ?> <?php echo e($allpoint->trans_amt); ?>

                                                        </span></td>

                                                    <th>₹<?php echo e($allpoint->balance); ?></th>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>
                                <?php else: ?>
                                    <div class="text-center">
                                        <h6>No Data Found</h6>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>

                    </div>

                </div>
                <div class=" px-4">
                    <?php echo $__env->make('imp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.userlayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u989572071/domains/deweca.com/public_html/ao/resources/views/my-point.blade.php ENDPATH**/ ?>