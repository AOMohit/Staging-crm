<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fira+Sans:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Geologica:wght@100;300&family=Lato&family=Open+Sans&family=Poppins&family=Roboto&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <title>Document</title>
    <link href="<?php echo e(asset('public/userpanel')); ?>/asset/css/style.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.0/css/toastr.css" rel="stylesheet" />
</head>
<body style="background-color: #FFF8EA">
    
    <div class="container py-5">
        <div class="col-10 d-block mx-auto bg-white p-3 rounded" style="width:640px ;height:530px;">
            <div class="row mb-3">
                <h5 class="text">  Verify your account and complete your profile!</h5>

                <p>Hi [User_Name],</p>
                <p>Your account has been successfully registered on Adventures Overland. Kindly click on the link below to fill your details:</p>

            </div>
            <a href="" class="button p-2 text-white">Open Link</a>
        </div>
        <div class="col-10 d-block mx-auto mt-4"style="width:640px">
            <div style="border-top:2px solid #D2E8FF">
               
            </div>

        </div>
        <div class="col-12">
            <div class="text-center mt-2">
                 <h6 class="font-size-14">
                    © 2024 Adventures Overland Pvt Ltd., All Rights Reserved.<br>
                1023, Tower B4, 10th Floor, Spaze IT Tech Park, Sohna Road, Gurugram, Haryana-122018 
                </h6>
                <p class="mt-4 font-size-10" >
                    This email was sent to [email address]. If you dont want to recieve these emails fom Adventures Overland in the future, please <br> unsubscribe from Adventures Overland Platform. <br>To help secure your account, please dont forward this email.</p>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\freelance\ao-new\resources\views/email.blade.php ENDPATH**/ ?>