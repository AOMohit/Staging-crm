
<style>
    label {
        margin-top: 10px;
    }
</style>
<?php
    $contry = allCountry();
?>
<?php $__env->startSection('container'); ?>
    <div class="col-md-10 col-12">
        <div class="border-shadow mb-4">
            <div class="card px-3">
                <div class="card-header bg-white information">
                    <?php echo $__env->make('layouts.userlayout.card-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class=" ">
                    <div class="">
                        <div class="p-2">
                            <div class="col-12">
                                <div class="row mt-4">
                                    <h6 class="fw-bold text pb-3">
                                        My Profile
                                    </h6>
                                    <div class="col-md-6 col-12">
                                        <div class="card border-shadow">
                                            <div class="card-body">
                                                <h5 class="fw-bold text">My Personal Information</h5>

                                                <div class="col-12 profile">
                                                    <table class="table">

                                                        <tbody class="profile-tbody">
                                                            <tr>
                                                                <th scope="row">First Name :</th>
                                                                <td><?php echo e(Auth::user()->first_name); ?></td>

                                                            </tr>
                                                            <tr>
                                                                <th scope="row">Last Name :</th>
                                                                <td><?php echo e(Auth::user()->last_name); ?></td>

                                                            </tr>
                                                            <tr>
                                                                <th scope="row">Email Id :</th>
                                                                <td colspan="2"><?php echo e(Auth::user()->email); ?></td>

                                                            </tr>
                                                            <tr>
                                                                <th scope="row">Phone No.:</th>
                                                                <td colspan="2"><?php echo e(Auth::user()->phone); ?></td>

                                                            </tr>
                                                            <tr>
                                                                <th scope="row">State :</th>
                                                                <td colspan="2"><?php echo e(Auth::user()->state); ?></td>

                                                            </tr>
                                                            <tr>
                                                                <th scope="row">City :</th>
                                                                <td colspan="2"><?php echo e(Auth::user()->city); ?></td>

                                                            </tr>
                                                            <tr>
                                                                <th scope="row">Pin code :</th>
                                                                <td colspan="2"><?php echo e(Auth::user()->pincode); ?></td>

                                                            </tr>
                                                            <tr>
                                                                <th scope="row">Address :</th>
                                                                <td colspan="2"><?php echo e(Auth::user()->address); ?></td>

                                                            </tr>
                                                            <tr>
                                                                <th scope="row">Country :</th>
                                                                <td colspan="2"><?php echo e(Auth::user()->country); ?></td>

                                                            </tr>
                                                            <tr>
                                                                <th scope="row">Date of Birth :</th>
                                                                <td colspan="2"><?php echo e(Auth::user()->dob); ?></td>

                                                            </tr>
                                                            <tr>
                                                                <th scope="row">Meal Preference :</th>
                                                                <td colspan="2"><?php echo e(Auth::user()->meal_preference); ?></td>

                                                            </tr>
                                                            <tr>
                                                                <th scope="row">Blood Group :</th>
                                                                <td colspan="2"><?php echo e(Auth::user()->blood_group); ?></td>

                                                            </tr>
                                                            <tr>
                                                                <th scope="row">Profession :</th>
                                                                <td colspan="2"><?php echo e(Auth::user()->profession); ?></td>

                                                            </tr>
                                                            <tr>
                                                                <th scope="row">Emergency Contact Number :</th>
                                                                <td colspan="2"><?php echo e(Auth::user()->emg_contact); ?></td>

                                                            </tr>
                                                            <tr>
                                                                <th scope="row">T-shirt Size :</th>
                                                                <td colspan="2"><?php echo e(Auth::user()->t_size); ?></td>

                                                            </tr>
                                                            <tr>
                                                                <th scope="row">Medical Condition if Any :</th>
                                                                <td colspan="2"><?php echo e(Auth::user()->medical_condition); ?>

                                                                </td>

                                                            </tr>
                                                            <tr>
                                                                <th scope="row">Vaccination :</th>
                                                                <td colspan="2"><?php echo e(Auth::user()->vaccination); ?> Dose
                                                                </td>

                                                            </tr>

                                                        </tbody>
                                                    </table>
                                                    <button class="button p-1 px-5 mt-2" data-bs-toggle="modal"
                                                        data-bs-target="#staticBackdrop">Edit</button>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12 earn-card">
                                        <div class="card border-shadow">
                                            <div class="card-body ">
                                                <h5 class="fw-bold text">My Personal Information</h5>
                                                <div class="profile mt-4">
                                                    <h6>Tell us something about yourself in 20 words :</h6>
                                                    <p><?php echo e(substr(Auth::user()->something, 0, 30)); ?>

                                                    <span class="collapse" id="collapseExample" style="font-size:14px;font-weight:normal">

                                                       <?php echo e(substr(Auth::user()->something, 30)); ?>


                                                    </span>
                                                    <a data-bs-toggle="collapse" href="#collapseExample" role="button"
                                                        aria-expanded="false" aria-controls="collapseExample"
                                                        class="blue">read more</a>
                                                    </p>

                                                </div>
                                                <div class="profile mt-3">
                                                    <h6>Have you done a road trip before? If yes, where? :</h6>
                                                    <p><?php echo e(substr(Auth::user()->have_road_trip, 0, 30)); ?> 
                                                    <span class="collapse" id="collapsehaveroad" style="font-size:14px;font-weight:normal">

                                                       <?php echo e(substr(Auth::user()->have_road_trip, 30)); ?>


                                                    </span>
                                                    <a data-bs-toggle="collapse" href="#collapsehaveroad" role="button"
                                                        aria-expanded="false" aria-controls="collapsehaveroad"
                                                        class="blue">read more</a>
                                                    </p>
                                                </div>
                                                <div class="profile mt-4">
                                                    <h6>Three Travel essentials for Road Trips? :</h6>
                                                    <p><?php echo e(substr(Auth::user()->three_travel, 0, 30)); ?> 
                                                    <span class="collapse" id="collapsethreetravel" style="font-size:14px;font-weight:normal">

                                                       <?php echo e(substr(Auth::user()->three_travel, 30)); ?>


                                                    </span>
                                                    <a data-bs-toggle="collapse" href="#collapsethreetravel" role="button"
                                                        aria-expanded="false" aria-controls="collapsethreetravel"
                                                        class="blue">read more</a>
                                                    </p>
                                                </div>
                                                <div class="profile mt-4">
                                                    <h6>Most Thrilling Experience of your life? :</h6>
                                                    <p><?php echo e(substr(Auth::user()->thrilling_exp, 0, 30)); ?> 
                                                        <span class="collapse" id="collapsethrilling_exp" style="font-size:14px;font-weight:normal">

                                                       <?php echo e(substr(Auth::user()->thrilling_exp, 30)); ?>


                                                    </span>
                                                    <a data-bs-toggle="collapse" href="#collapsethrilling_exp" role="button"
                                                        aria-expanded="false" aria-controls="collapsethrilling_exp"
                                                        class="blue">read more</a>
                                                    </p>
                                                </div>
                                                <div class="profile mt-4">
                                                    <h6>Three places in your bucket list? :</h6>
                                                    <p><?php echo e(substr(Auth::user()->three_place, 0, 3)); ?>

                                                    <span class="collapse" id="collapsethree_place" style="font-size:14px;font-weight:normal">

                                                       <?php echo e(substr(Auth::user()->three_place, 3)); ?>


                                                    </span>
                                                    <a data-bs-toggle="collapse" href="#collapsethree_place" role="button"
                                                        aria-expanded="false" aria-controls="collapsethree_place"
                                                        class="blue">read more</a>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                    <!-- Modal -->
                                    <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static"
                                        data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel"
                                        aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title text fw-bold" id="staticBackdropLabel">Profile
                                                        Update</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="<?php echo e(route('profile.update')); ?>" method="post"
                                                        enctype="multipart/form-data">
                                                        <?php echo csrf_field(); ?>
                                                        
                                                        <div class="row p-2">
                                                            <div class="col-md-6 col-12">
                                                                <div>
                                                                    <label for="">First Name</label>
                                                                    <input type="text" required name="first_name"
                                                                        value="<?php echo e(Auth::user()->first_name); ?>"
                                                                        class="form-control" id="">
                                                                </div>
                                                                <div>
                                                                    <label for="">Email Id</label>
                                                                    <input type="text"
                                                                        value="<?php echo e(Auth::user()->email); ?>" readonly
                                                                        class="form-control" id="">
                                                                </div>
                                                                <div>
                                                                    <label for="">Phone No</label>
                                                                    <input type="text" required name="phone"
                                                                        value="<?php echo e(Auth::user()->phone); ?>"
                                                                        class="form-control" id="">
                                                                </div>
                                                                <div>
                                                                    <label for="">Country</label>
                                                                    <select name="country" id=""
                                                                        class="form-control"
                                                                        onchange="getState(this.value)">
                                                                        <option>Select Country</option>
                                                                        <?php $__currentLoopData = $contry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contrys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($contrys->name); ?>">
                                                                                <?php echo e($contrys->name); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                    
                                                                </div>
                                                                <div>
                                                                    <label for="">State</label>
                                                                    <input type="text" name="state"
                                                                        value="<?php echo e(Auth::user()->state); ?>"
                                                                        class="form-control" id="">
                                                                </div>
                                                                <div>
                                                                    <label for="">City</label>
                                                                    <input type="text" name="city"
                                                                        value="<?php echo e(Auth::user()->city); ?>"
                                                                        class="form-control" id="">
                                                                </div>
                                                                <div>
                                                                    <label for="">Address</label>
                                                                    <input type="text" name="address"
                                                                        value="<?php echo e(Auth::user()->address); ?>"
                                                                        class="form-control" id="">
                                                                </div>
                                                                <div>
                                                                    <label for="">Pincode</label>
                                                                    <input type="text" name="pincode"
                                                                        value="<?php echo e(Auth::user()->pincode); ?>"
                                                                        class="form-control" id="">
                                                                </div>

                                                                <div>
                                                                    <label for="">Date of Birth</label>
                                                                    <input type="date" name="dob"
                                                                        value="<?php echo e(Auth::user()->dob); ?>"
                                                                        class="form-control" id="">
                                                                </div>

                                                            </div>
                                                            <div class="col-md-6 col-12">
                                                                <div>
                                                                    <label for="">Last Name</label>
                                                                    <input type="text" name="last_name"
                                                                        value="<?php echo e(Auth::user()->last_name); ?>"
                                                                        class="form-control" id="">
                                                                </div>
                                                                <div>
                                                                    <label for="">Meal Preference</label>
                                                                    <input type="text" name="meal_preference"
                                                                        value="<?php echo e(Auth::user()->meal_preference); ?>"
                                                                        class="form-control" id="">
                                                                </div>
                                                                <div>
                                                                    <label for="">Blood Group</label>
                                                                    <select name="blood_group" class="w-100 form-control"
                                                                        id="" required>
                                                                        <option value="">—Please choose an option—
                                                                        </option>
                                                                        <option
                                                                            <?php if(Auth::user()->blood_group == 'a+'): ?> selected <?php endif; ?>
                                                                            value="a+">A+
                                                                        </option>
                                                                        <option
                                                                            <?php if(Auth::user()->blood_group == 'a-'): ?> selected <?php endif; ?>
                                                                            value="a-">A-
                                                                        </option>
                                                                        <option
                                                                            <?php if(Auth::user()->blood_group == 'b+'): ?> selected <?php endif; ?>
                                                                            value="b+">B+
                                                                        </option>
                                                                        <option
                                                                            <?php if(Auth::user()->blood_group == 'b-'): ?> selected <?php endif; ?>
                                                                            value="b-">B-
                                                                        </option>
                                                                        <option
                                                                            <?php if(Auth::user()->blood_group == 'o+'): ?> selected <?php endif; ?>
                                                                            value="o+">O+
                                                                        </option>
                                                                        <option
                                                                            <?php if(Auth::user()->blood_group == 'o-'): ?> selected <?php endif; ?>
                                                                            value="o-">O-
                                                                        </option>
                                                                        <option
                                                                            <?php if(Auth::user()->blood_group == 'ab+'): ?> selected <?php endif; ?>
                                                                            value="ab+">AB+
                                                                        </option>
                                                                        <option
                                                                            <?php if(Auth::user()->blood_group == 'ab-'): ?> selected <?php endif; ?>
                                                                            value="ab-">AB-
                                                                        </option>

                                                                    </select>
                                                                </div>
                                                                <div>
                                                                    <label for="">Profession</label>
                                                                    <input type="text" name="profession"
                                                                        value="<?php echo e(Auth::user()->profession); ?>"
                                                                        class="form-control" id="">
                                                                </div>
                                                                <div>
                                                                    <label for="">Emergency Contact Number</label>
                                                                    <input type="text" name="emg_contact"
                                                                        value="<?php echo e(Auth::user()->emg_contact); ?>"
                                                                        class="form-control" id="">
                                                                </div>
                                                                <div>
                                                                    <label for="">T-shirt Size</label>
                                                                    <select name="t_size" class="w-100 form-control"
                                                                        id="" required>
                                                                        <option value="">—Please choose an option—
                                                                        </option>
                                                                        <option
                                                                            <?php if(Auth::user()->t_size == 'Kids'): ?> selected <?php endif; ?>
                                                                            value="Kids">Kids
                                                                        </option>
                                                                        <option
                                                                            <?php if(Auth::user()->t_size == 'XS'): ?> selected <?php endif; ?>
                                                                            value="XS">XS
                                                                        </option>
                                                                        <option
                                                                            <?php if(Auth::user()->t_size == 'S'): ?> selected <?php endif; ?>
                                                                            value="S">S
                                                                        </option>
                                                                        <option
                                                                            <?php if(Auth::user()->t_size == 'M'): ?> selected <?php endif; ?>
                                                                            value="M">M
                                                                        </option>
                                                                        <option
                                                                            <?php if(Auth::user()->t_size == 'L'): ?> selected <?php endif; ?>
                                                                            value="L">L
                                                                        </option>
                                                                        <option
                                                                            <?php if(Auth::user()->t_size == '2XL'): ?> selected <?php endif; ?>
                                                                            value="2XL">2XL
                                                                        </option>
                                                                        <option
                                                                            <?php if(Auth::user()->t_size == '3XL'): ?> selected <?php endif; ?>
                                                                            value="3XL">3XL
                                                                        </option>


                                                                    </select>
                                                                </div>
                                                                <div>
                                                                    <label for="">Medical Condition if Any</label>
                                                                    <input type="text" name="medical_condition"
                                                                        value="<?php echo e(Auth::user()->medical_condition); ?>"
                                                                        class="form-control" id="">
                                                                </div>
                                                                <div>
                                                                    <label for="">Vaccination</label>
                                                                    <select name="vaccination" class="w-100 form-control"
                                                                        id="" required>
                                                                        <option value="">—Please choose an option—
                                                                        </option>
                                                                        <option
                                                                            <?php if(Auth::user()->vaccination == 'Singel'): ?> selected <?php endif; ?>
                                                                            value="Singel">Singel</option>
                                                                        <option
                                                                            <?php if(Auth::user()->vaccination == 'Double'): ?> selected <?php endif; ?>
                                                                            value="Double">Double</option>
                                                                        <option
                                                                            <?php if(Auth::user()->vaccination == 'None'): ?> selected <?php endif; ?>
                                                                            value="None">None</option>


                                                                    </select>
                                                                </div>
                                                                <div>
                                                                    <label for="">Profile Image</label><br>
                                                                    <?php if(isset(Auth::user()->profile)): ?>
                                                                        <img src="<?php echo e(asset('storage/app/' . Auth::user()->profile)); ?>"
                                                                            alt="" width="100px">
                                                                    <?php endif; ?>
                                                                    <input type="file" name="profile"
                                                                        value="<?php echo e(Auth::user()->profile); ?>"
                                                                        class="form-control mt-2" id="">
                                                                </div>


                                                            </div>
                                                            <div class="text-center mt-4">
                                                                <button type="submit"
                                                                    class="button px-5 p-2 w-100">Upadate</button>
                                                            </div>

                                                    </form>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- important note -->
                <div class="mt-5 important-note px-4">
                    <?php echo $__env->make('imp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>


            </div>
        </div>
    </div>
    <script></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.userlayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\freelance\ao-new\resources\views/profile-page.blade.php ENDPATH**/ ?>