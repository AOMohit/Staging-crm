<?php $__env->startSection('container'); ?>
    <div class="col-md-10 col-12">
        <div class="border-shadow">
            <div class="card-body">
                <div class="background-2 rounded p-2 overview w-100">
                    <p class="text ">
                       <?php echo setting('about_us'); ?>

                    </p>
                </div>

                <div class="mt-3">
                    <h6 class="text fw-bold">Current Tier</h6>
                    <div class="row mt-3">
                        <div class="col-md-3 col-12 overview-img">
                            
                            <?php if($user->tier == 'Discovery'): ?>
                                <img src="<?php echo e(asset('public/userpanel')); ?>/asset/images/overview-page.png" alt="">
                            <?php elseif($user->tier == 'Adventurer'): ?>
                                <img src="<?php echo e(asset('public/userpanel')); ?>/asset/images/Discovery.png" alt="">
                            <?php elseif($user->tier == 'Explorer'): ?>
                                <img src="<?php echo e(asset('public/userpanel')); ?>/asset/images/explore.png" alt="">
                            <?php elseif($user->tier == 'Legends'): ?>
                                <img src="<?php echo e(asset('public/userpanel')); ?>/asset/images/legends.png" alt="">
                            <?php endif; ?>
                        </div>
                        <div class="col-md-9 col-12 overview-cards">
                            <span class=" rounded shadows bg-white p-3">

                                <span class="font-size-14 font-size-mobile-14 fw-bold text"> You Have Total</span>
                                &nbsp; <img src="<?php echo e(asset('public/userpanel')); ?>/asset/images/star.svg" alt="">
                                <span class="fw-bold font-size-20 font-size-mobile-20"><?php echo e(Auth::user()->points); ?></span>
                                <small class="font-size-10 font-size-mobile-10">Points</small>
                                &nbsp; <small class="font-size-9 font-size-mobile-9">Expiring on: 26th Jan, 2023</small>

                            </span>
                            <div class="d-flex justify-content-between mt-4 overview">
                                <h6 class="text fw-bold">Tier Level</h6>
                                <p class="lavel active " data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="Tooltip with svg">
                                    <img src="<?php echo e(asset('public/userpanel')); ?>/asset/images/lock.svg" alt="">
                                    Discovery
                                </p>
                                <p class="lavel level-adventure" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="Tooltip with svg"> <img
                                        src="<?php echo e(asset('public/userpanel')); ?>/asset/images/not-active-lock.svg"
                                        alt="" id="image-adventurer"> Adventurer</p>
                                <p class="lavel level-explore" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="Tooltip with svg"> <img
                                        src="<?php echo e(asset('public/userpanel')); ?>/asset/images/not-active-lock.svg"
                                        id="image-explorer" alt=""> Explorer</p>
                                <p class="lavel level-legends" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="Tooltip with svg"> <img
                                        src="<?php echo e(asset('public/userpanel')); ?>/asset/images/not-active-lock.svg"
                                        id="image-legend" alt=""> Legends</p>

                            </div>
                            <div class="range mb-3">
                                <div class="d-flex">
                                    <div class="range-division-start range-active"></div>
                                    <div class="range-division-middel range-active"></div>
                                    <div class="range-division-middel range-division-middel-1"></div>
                                    <div class="range-division-middel range-division-middel-1"></div>
                                    <div class="range-division-middel range-division-middel-2"></div>
                                    <div class="range-division-middel range-division-middel-2"></div>
                                    <div class="range-division-middel range-division-end1"></div>
                                    <div class="range-division-end"></div>
                                </div>
                            </div>
                            <span class="text">You need to earn 10K+ points to move to <span
                                    class="fw-bold">Adventurer</span> tier and start earning 2% of total spends.</span>
                        </div>
                    </div>

                </div>
                <?php echo $__env->make('imp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

    <script>
        jQuery(document).ready(function() {
            var tier = '<?php echo e($user->tier); ?>';
            // alert(tier);
            if (tier == 'Adventurer') {
                $('.level-adventure').addClass('active');
                $('#image-adventurer').attr("src", "<?php echo e(asset('public/userpanel')); ?>/asset/images/lock.svg")
                $('.range-division-middel-1').addClass('range-active');
            }
            if (tier == 'Explorer') {
                $('.level-explore').addClass('active');
                $('.level-adventure').addClass('active');
                $('.range-division-middel-1').addClass('range-active');

                $('.range-division-middel-2').addClass('range-active');

                $('#image-explorer').attr("src", "<?php echo e(asset('public/userpanel')); ?>/asset/images/lock.svg")
                $('#image-adventurer').attr("src", "<?php echo e(asset('public/userpanel')); ?>/asset/images/lock.svg")
            }
            if (tier == 'Legends') {
                $('.level-legends').addClass('active');
                $('.level-explore').addClass('active');
                $('.level-adventure').addClass('active');
                $('.range-division-middel-1').addClass('range-active');

                $('.range-division-middel-2').addClass('range-active');
                $('.range-division-end1').addClass('range-active');
                $('.range-division-end').addClass('range-active');

                $('#image-adventurer').attr("src", "<?php echo e(asset('public/userpanel')); ?>/asset/images/lock.svg")
                $('#image-explorer').attr("src", "<?php echo e(asset('public/userpanel')); ?>/asset/images/lock.svg")
                $('#image-legend').attr("src", "<?php echo e(asset('public/userpanel')); ?>/asset/images/lock.svg")


            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.userlayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\freelance\ao-new\resources\views/dashboard.blade.php ENDPATH**/ ?>