
<style>
    label{
        margin-top: 10px;
    }
</style>
<?php
    $contry = allCountry();
?>
<?php $__env->startSection('container'); ?>

<div class="col-md-10 col-12">
    <div class="border-shadow mb-4">
        <div class="card px-3">
            <div class="card-header bg-white information">
                <?php echo $__env->make('layouts.userlayout.card-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class=" ">
                <div class="">
                    <div class="p-2">
                        <div class="col-12">
                            <div class="row mt-4">
                                <h6 class="fw-bold text pb-3">
                                    My Profile
                                </h6>
                                <div class="col-md-6 col-12">
                                    <div class="card border-shadow">
                                        <div class="card-body">
                                            <h5 class="fw-bold text">My Personal Information</h5>

                                            <div class="col-12 profile">
                                                <table class="table">

                                                    <tbody class="profile-tbody">
                                                        <tr>
                                                            <th scope="row">First Name :</th>
                                                            <td><?php echo e(Auth::user()->first_name); ?></td>

                                                        </tr>
                                                        <tr>
                                                            <th scope="row">Last Name :</th>
                                                            <td><?php echo e(Auth::user()->last_name); ?></td>

                                                        </tr>
                                                        <tr>
                                                            <th scope="row">Email Id :</th>
                                                            <td colspan="2"><?php echo e(Auth::user()->email); ?></td>

                                                        </tr>
                                                        <tr>
                                                            <th scope="row">Phone No.:</th>
                                                            <td colspan="2"><?php echo e(Auth::user()->phone); ?></td>

                                                        </tr>
                                                        <tr>
                                                            <th scope="row">State :</th>
                                                            <td colspan="2"><?php echo e(Auth::user()->state); ?></td>

                                                        </tr>
                                                        <tr>
                                                            <th scope="row">City :</th>
                                                            <td colspan="2"><?php echo e(Auth::user()->city); ?></td>

                                                        </tr>
                                                        <tr>
                                                            <th scope="row">Pin code :</th>
                                                            <td colspan="2"><?php echo e(Auth::user()->pincode); ?></td>

                                                        </tr>
                                                        <tr>
                                                            <th scope="row">Address :</th>
                                                            <td colspan="2"><?php echo e(Auth::user()->address); ?></td>

                                                        </tr>
                                                        <tr>
                                                            <th scope="row">Country :</th>
                                                            <td colspan="2"><?php echo e(Auth::user()->country); ?></td>

                                                        </tr>
                                                        <tr>
                                                            <th scope="row">Date of Birth :</th>
                                                            <td colspan="2"><?php echo e(Auth::user()->dob); ?></td>

                                                        </tr>
                                                        <tr>
                                                            <th scope="row">Meal Preference :</th>
                                                            <td colspan="2"><?php echo e(Auth::user()->meal_preference); ?></td>

                                                        </tr>
                                                        <tr>
                                                            <th scope="row">Blood Group :</th>
                                                            <td colspan="2"><?php echo e(Auth::user()->blood_group); ?></td>

                                                        </tr>
                                                        <tr>
                                                            <th scope="row">Profession :</th>
                                                            <td colspan="2"><?php echo e(Auth::user()->profession); ?></td>

                                                        </tr>
                                                        <tr>
                                                            <th scope="row">Emergency Contact Number :</th>
                                                            <td colspan="2"><?php echo e(Auth::user()->emg_contact); ?></td>

                                                        </tr>
                                                        <tr>
                                                            <th scope="row">T-shirt Size :</th>
                                                            <td colspan="2"><?php echo e(Auth::user()->t_size); ?></td>

                                                        </tr>
                                                        <tr>
                                                            <th scope="row">Medical Condition if Any :</th>
                                                            <td colspan="2"><?php echo e(Auth::user()->medical_condition); ?></td>

                                                        </tr>
                                                        <tr>
                                                            <th scope="row">Vaccination :</th>
                                                            <td colspan="2"><?php echo e(Auth::user()->vaccination); ?> Dose</td>

                                                        </tr>

                                                    </tbody>
                                                </table>
                                                <button class="button p-1 px-5 mt-2" data-bs-toggle="modal" data-bs-target="#staticBackdrop">Edit</button>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-12 earn-card">
                                    <div class="card border-shadow">
                                        <div class="card-body ">
                                            <h5 class="fw-bold text">My Personal Information</h5>
                                            <div class="profile mt-4">
                                                <h6>Tell us something about yourself in 20 words :</h6>
                                                <p>Lorem ipsum dolor sit amet, consectetur <a href="" class="blue">read more</a></p>
                                            </div>
                                            <div class="profile mt-3">
                                                <h6>Have you done a road trip before? If yes, where? :</h6>
                                                <p>Lorem ipsum dolor sit amet, consectetur <a href="" class="blue">read more</a></p>
                                            </div>
                                            <div class="profile mt-4">
                                                <h6>Three Travel essentials for Road Trips? :</h6>
                                                <p>Lorem ipsum dolor sit amet, consectetur <a href="" class="blue">read more</a></p>
                                            </div>
                                            <div class="profile mt-4">
                                                <h6>Most Thrilling Experience of your life? :</h6>
                                                <p>Lorem ipsum dolor sit amet, consectetur <a href="" class="blue">read more</a></p>
                                            </div>
                                            <div class="profile mt-4">
                                                <h6>Three places in your bucket list? :</h6>
                                                <p>Lorem ipsum dolor sit amet, consectetur <a href="" class="blue">read more</a></p>
                                            </div>
                                        </div>
                                    </div>


                                </div>
                                <!-- Modal -->
                                <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-lg">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title text fw-bold" id="staticBackdropLabel">Profile Update</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <form action="<?php echo e(route('profile.update')); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    
                                                    <div class="row p-2">
                                                        <div class="col-md-6 col-12">
                                                            <div>
                                                                <label for="">First Name</label>
                                                                <input type="text" required name="first_name" value="<?php echo e(Auth::user()->first_name); ?>" class="form-control" id="">
                                                            </div>
                                                            <div>
                                                                <label for="">Email Id</label>
                                                                <input type="text"  value="<?php echo e(Auth::user()->email); ?>" readonly class="form-control" id="">
                                                            </div>
                                                            <div>
                                                                <label for="">Phone No</label>
                                                                <input type="text" required name="phone" value="<?php echo e(Auth::user()->phone); ?>" class="form-control" id="">
                                                            </div>
                                                             <div>
                                                                <label for="">Country</label>
                                                                <select name="country" id="" class="form-control" onchange="getState(this.value)">
                                                                    <option >Select Country</option>
                                                                    <?php $__currentLoopData = $contry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contrys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($contrys->name); ?>"><?php echo e($contrys->name); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                                
                                                            </div>
                                                            <div>
                                                                <label for="">State</label>
                                                                <input type="text" name="state" value="<?php echo e(Auth::user()->state); ?>" class="form-control" id="">
                                                            </div>
                                                            <div>
                                                                <label for="">City</label>
                                                                <input type="text" name="city" value="<?php echo e(Auth::user()->city); ?>" class="form-control" id="">
                                                            </div>
                                                            <div>
                                                                <label for="">Address</label>
                                                                <input type="text" name="address" value="<?php echo e(Auth::user()->address); ?>" class="form-control" id="">
                                                            </div>
                                                            <div>
                                                                <label for="">Pincode</label>
                                                                <input type="text" name="pincode" value="<?php echo e(Auth::user()->pincode); ?>" class="form-control" id="">
                                                            </div>
                                                           
                                                            <div>
                                                                <label for="">Date of Birth</label>
                                                                <input type="date" name="dob" value="<?php echo e(Auth::user()->dob); ?>" class="form-control" id="">
                                                            </div>

                                                        </div>
                                                        <div class="col-md-6 col-12">
                                                            <div>
                                                                <label for="">Last Name</label>
                                                                <input type="text" name="last_name" value="<?php echo e(Auth::user()->last_name); ?>" class="form-control" id="">
                                                            </div>
                                                            <div>
                                                                <label for="">Meal Preference</label>
                                                                <input type="text" name="meal_preference" value="<?php echo e(Auth::user()->meal_preference); ?>" class="form-control" id="">
                                                            </div>
                                                            <div>
                                                                <label for="">Blood Group</label>
                                                                <input type="text" name="blood_group" value="<?php echo e(Auth::user()->blood_group); ?>" class="form-control" id="">
                                                            </div>
                                                            <div>
                                                                <label for="">Profession</label>
                                                                <input type="text" name="profession" value="<?php echo e(Auth::user()->profession); ?>" class="form-control" id="">
                                                            </div>
                                                            <div>
                                                                <label for="">Emergency Contact Number</label>
                                                                <input type="text" name="emg_contact" value="<?php echo e(Auth::user()->emg_contact); ?>" class="form-control" id="">
                                                            </div>
                                                            <div>
                                                                <label for="">T-shirt Size</label>
                                                                <input type="text" name="t_size" value="<?php echo e(Auth::user()->t_size); ?>" class="form-control" id="">
                                                            </div>
                                                            <div>
                                                                <label for="">Medical Condition if Any</label>
                                                                <input type="text" name="medical_condition" value="<?php echo e(Auth::user()->medical_condition); ?>" class="form-control" id="">
                                                            </div>
                                                            <div>
                                                                <label for="">Vaccination</label>
                                                                <input type="text" name="vaccination" value="<?php echo e(Auth::user()->vaccination); ?>" class="form-control" id="">
                                                            </div>
                                                            <div class="text-center mt-4">
                                                                <button type="submit" class="button px-5 p-2 w-100">Upadate</button>
                                                            </div>

                                                        </div>
                                                        
                                                </form>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- important note -->
            <div class="mt-5 important-note px-4">

                <h6 class="text fw-bold">Important Note:</h6>
                <ul class="mt-5">
                    <li>Points earned in the Adventures Overland Loyalty Programme are transferable between members.
                    </li>
                    <li>To initiate a points transfer, both the sender and recipient must confirm the transaction through their respective accounts.</li>
                    <li>Transferred points retain their original value and can be used for bookings, discounts, and other eligible rewards.</li>
                    <li>Adventures Overland reserves the right to impose reasonable limits on the frequency and quantity of point transfers.</li>
                    <li>The transfer feature is designed to enhance the flexibility of the loyalty programme and foster a sense of community among our members.</li>
                    <li>Any attempted misuse or fraudulent activity related to points transfer may result in the suspension of the involved accounts.</li>
                </ul>

            </div>

            <div class="p-3 term-condition">
                <a href="#">Terms & Conditions <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12" fill="none">
                        <path d="M10.798 5.96301H9.95046C9.77494 5.96301 9.63264 6.10531 9.63264 6.28084V10.145C9.63264 10.3501 9.46572 10.517 9.26062 10.517H1.85503C1.64997 10.517 1.48318 10.3501 1.48318 10.145V2.73952C1.48318 2.53437 1.64997 2.36745 1.85503 2.36745H5.91703C6.09255 2.36745 6.23485 2.22515 6.23485 2.04963V1.2021C6.23485 1.02658 6.09255 0.884277 5.91703 0.884277H1.85503C0.832147 0.884277 0 1.71655 0 2.73952V10.145C0 11.168 0.832189 12.0002 1.85503 12.0002H9.26057C10.2835 12.0002 11.1158 11.1679 11.1158 10.145V6.28088C11.1158 6.10531 10.9735 5.96301 10.798 5.96301Z" fill="#FFB224" />
                        <path d="M11.6822 0H8.31101C8.13549 0 7.99319 0.1423 7.99319 0.317824V1.16535C7.99319 1.34088 8.13549 1.48318 8.31101 1.48318H9.46806L5.11409 5.83706C4.98997 5.96118 4.98997 6.16239 5.11409 6.28655L5.71337 6.88588C5.773 6.9455 5.85381 6.97898 5.93814 6.97898C6.02243 6.97898 6.10328 6.9455 6.16286 6.88588L10.5168 2.53191V3.68891C10.5168 3.86444 10.6591 4.00674 10.8347 4.00674H11.6822C11.8577 4.00674 12 3.86444 12 3.68891V0.317824C12 0.1423 11.8577 0 11.6822 0Z" fill="#FFB224" />
                    </svg></a>
                <a href="#" class="ps-4">FAQ’s <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12" fill="none">
                        <path d="M10.798 5.96301H9.95046C9.77494 5.96301 9.63264 6.10531 9.63264 6.28084V10.145C9.63264 10.3501 9.46572 10.517 9.26062 10.517H1.85503C1.64997 10.517 1.48318 10.3501 1.48318 10.145V2.73952C1.48318 2.53437 1.64997 2.36745 1.85503 2.36745H5.91703C6.09255 2.36745 6.23485 2.22515 6.23485 2.04963V1.2021C6.23485 1.02658 6.09255 0.884277 5.91703 0.884277H1.85503C0.832147 0.884277 0 1.71655 0 2.73952V10.145C0 11.168 0.832189 12.0002 1.85503 12.0002H9.26057C10.2835 12.0002 11.1158 11.1679 11.1158 10.145V6.28088C11.1158 6.10531 10.9735 5.96301 10.798 5.96301Z" fill="#FFB224" />
                        <path d="M11.6822 0H8.31101C8.13549 0 7.99319 0.1423 7.99319 0.317824V1.16535C7.99319 1.34088 8.13549 1.48318 8.31101 1.48318H9.46806L5.11409 5.83706C4.98997 5.96118 4.98997 6.16239 5.11409 6.28655L5.71337 6.88588C5.773 6.9455 5.85381 6.97898 5.93814 6.97898C6.02243 6.97898 6.10328 6.9455 6.16286 6.88588L10.5168 2.53191V3.68891C10.5168 3.86444 10.6591 4.00674 10.8347 4.00674H11.6822C11.8577 4.00674 12 3.86444 12 3.68891V0.317824C12 0.1423 11.8577 0 11.6822 0Z" fill="#FFB224" />
                    </svg></a>
            </div>
        </div>
    </div>
</div>
<script></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.userlayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\freelance\hotelTrip\resources\views/profile-page.blade.php ENDPATH**/ ?>