
<?php $__env->startSection('container'); ?>

<div class="col-md-10 col-12">
    <div class="border-shadow">
        <div class="card">
            <div class="card-header bg-white information">
                <?php echo $__env->make('layouts.userlayout.card-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="card-body">
                <h6 class="text fw-bold mb-5">Booked Trip History</h6>
                <?php if(count($trip)>0): ?>
                <?php $__currentLoopData = $trip; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trips): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
               
                <div class="col-12 mt-3">
                    <div class="card border-shadow">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-8">
                                    <div class="row trip-dates">
                                        <div class="col-md-4 col-12">

                                            <span>Trip Start Date:</span><span class="fw-bold trip-date"> <?php echo e(date('d M, Y', strtotime($trips->trip->start_date ?? null))); ?></span>
                                        </div>
                                        <div class="col-md-4 col-12 ">

                                            <span class="">Trip End Date:</span><span class="fw-bold trip-date"><?php echo e(date('d M, Y', strtotime($trips->trip->end_date ?? null))); ?></span>
                                        </div>
                                        <div class="col-md-4 col-12">
                                            <span class=" <?php if($trips->trip_status =='Cancelled'): ?> bg-danger <?php elseif($trips->trip_status =='Completed' || $trips->trip_status =='Confirmed'): ?> bg-success <?php elseif($trips->trip_status =='Correction'): ?> bg-warning  <?php elseif($trips->trip_status =='Draft'): ?> bg-secondary  <?php endif; ?> p-1 px-3 ms-3 rounded text-white"><?php echo e($trips->trip_status); ?></span>

                                        </div>



                                    </div>
                                </div>
                                <div class="col-4 text-end trip-details">
                                    <a href="<?php echo e(route('tripDetails',['token'=>$trips->token])); ?>" class="fw-bold">Trip Details ></a>
                                </div>
                            </div>
                            <h5 class="fw-bold mt-2"><?php echo e($trips->trip->name ?? null); ?></h5>
                        </div>
                    </div>
                </div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="text-center mt-5">
                        <h5>No Data Found !</h5>
                    </div>
                <?php endif; ?>
               <?php echo $__env->make('imp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.userlayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ao\resources\views/my-trip.blade.php ENDPATH**/ ?>