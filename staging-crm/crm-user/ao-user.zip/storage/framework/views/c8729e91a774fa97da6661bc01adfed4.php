<?php echo e($slot); ?>

<?php /**PATH /home/codesgro/ao.codesground.com/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>