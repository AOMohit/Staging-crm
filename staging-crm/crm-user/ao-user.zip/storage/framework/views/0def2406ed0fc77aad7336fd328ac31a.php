<?php echo $__env->make('layouts.userlayout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('container'); ?>

<?php echo $__env->make('layouts.userlayout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u679865197/domains/adventuresoverland.com/public_html/crm-user/resources/views/layouts/userlayout/index.blade.php ENDPATH**/ ?>