<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional //EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
                <html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
                
                <head>
                
                  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
                  <meta name="viewport" content="width=device-width, initial-scale=1.0">
                  <meta name="x-apple-disable-message-reformatting">
                
                  
                  <!-- Start stylesheet -->
                    <style type="text/css">
                      a,a[href],a:hover, a:link, a:visited {
                        /* This is the link colour */
                        text-decoration: none!important;
                        color: #0000EE;
                      }
                      .link {
                        text-decoration: underline!important;
                      }
                      h1 {
                        /* Fallback heading style */
                        font-size:22px;
                        line-height:24px;
                        font-family:'Helvetica', Arial, sans-serif;
                        font-weight:normal;
                        text-decoration:none;
                        color: #000000;
                      }
                      .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td {line-height: 100%;}
                      .ExternalClass {width: 100%;}
                    </style>
                    <!-- End stylesheet -->
                  
                </head>
                
                  <!-- You can change background colour here -->
                  <body style="text-align: center; margin: 0; padding-top: 10px; padding-bottom: 10px; padding-left: 0; padding-right: 0; -webkit-text-size-adjust: 100%;background-color: #fff8ea; color: #000000" align="center">
                  
                  <!-- Fallback force center content -->
                  <div style="text-align: center;">
                
                    
                    <!-- Start container for logo -->
                    <table align="center" style="text-align: center; vertical-align: top; width: 600px; max-width: 600px; background-color: #fff8ea;" width="600">
                      <tbody>
                        <tr>
                          <td style="width: 596px; vertical-align: top; padding-left: 0; padding-right: 0; padding-top: 15px; padding-bottom: 15px;" width="596">
                
                            <!-- Your logo is here -->
                            <img src="<?php echo e(env('ADMIN_URL').'storage/app/'.setting('logo')); ?>" style="width:auto;height:56px">
                
                          </td>
                        </tr>
                      </tbody>
                    </table>
                    <!-- End container for logo -->
                
                    <!-- Start single column section -->
                    <table align="center" style="text-align: left; border-radius: 10px; vertical-align: top; width: 600px; max-width: 600px; background-color: #ffffff;" width="600">
                        <tbody>
                          <tr>
                            <td style="font-size: 15px; line-height: 24px; font-family: 'Helvetica', Arial, sans-serif; font-weight: 400; text-decoration: none; color: #383838; width: 596px; vertical-align: top; padding-left: 30px; padding-right: 30px; padding-top: 30px; padding-bottom: 40px;" width="596">
                
                              <p>Hello <?php echo e($mailData['first_name']); ?> <?php echo e($mailData['last_name']); ?>,</p>
                <p>
                    You have received <strong><?php echo e($mailData['points']); ?></strong> points from <strong><?php echo e($mailData['sender_mail']); ?></strong> . You can redeem them anytime on our platform for your next trip.<br>For further details regarding validity and other inquiries, please reach out to our Travel Expert.
                </p>
                
                            </td>
                          </tr>
                        </tbody>
                      </table>
                      <!-- End single column section -->    
                      <!-- Start unsubscribe section -->
                      <table align="center" style="text-align: center; vertical-align: top; width: 600px; max-width: 600px;" width="600">
                        <tbody>
                          <tr>
                            <td style="width: 596px; vertical-align: top; padding-left: 30px; padding-right: 30px; padding-top: 30px; padding-bottom: 30px;" width="596">
                              
                              <p style="font-size: 13px; font-weight: bold; line-height: 18px; font-family: 'Helvetica', Arial, sans-serif; font-weight: normal; text-decoration: none; color: #000000;">
                              <strong>  ©️ 2024 Adventures Overland Pvt Ltd., All Rights Reserved.
1006 – 1008, Tower B4, 10th Floor, Spaze IT Tech Park, Sohna Road, Gurugram, Haryana-122018<br>
Contact Nos. 919911599811 | +91 9971891243</strong>
                              </p>
                
                              <p style="font-size: 12px; line-height: 15px; font-family: 'Helvetica', Arial, sans-serif; font-weight: normal; text-decoration: none; color: #000000;">
                                This email was sent to <?php echo e($mailData['email']); ?>.<br>
                To help secure your account, please dont forward this email.
                              </p>
                
                            </td>
                          </tr>
                        </tbody>
                      </table>
                      <!-- End unsubscribe section -->
                  
                  </div>
                
                  </body>
                
                </html><?php /**PATH /home/u679865197/domains/adventuresoverland.com/public_html/crm-user/resources/views/emails/transfer-reciver.blade.php ENDPATH**/ ?>