
<style>
    th {
        white-space: nowrap;
    }
    td {
        white-space:nowrap;
    }
.table>:not(caption)>*>* {
    padding: 0.5rem 0.5rem;
    background-color: var(--bs-table-bg);
    border-bottom-width: 0 !important;
    box-shadow: inset 0 0 0 9999px var(--bs-table-accent-bg);
}
</style>
<?php $__env->startSection('container'); ?>
    <div class="col-md-10 col-12">
        <div class="border-shadow">
            <div class="card">
                <div class="card-header bg-white information">
                    <?php echo $__env->make('layouts.userlayout.card-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <h6 class="text fw-bold mb-4">Trip Detail Page</h6>

                        <div class=" d-block d-md-none">

                             <?php if(isset($data->invoice_file)): ?>
                                    <a href="<?php echo e(env('ADMIN_URL').$data->invoice_file); ?>" target="_blank">

                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="22"
                                            viewBox="0 0 20 22" fill="none">
                                            <path d="M6.45166 6.45142H11.613V7.74174H6.45166V6.45142Z" fill="#FFB224" />
                                            <path d="M6.45166 9.03223H11.613V10.3225H6.45166V9.03223Z" fill="#FFB224" />
                                            <path d="M6.45166 3.87085H11.613V5.16117H6.45166V3.87085Z" fill="#FFB224" />
                                            <path
                                                d="M6.45166 15.4838H10.0096C10.3381 14.5575 10.8952 13.7386 11.613 13.0954V11.6128H6.45166V15.4838Z"
                                                fill="#FFB224" />
                                            <path
                                                d="M9.71346 16.7742C7.49265 16.7742 4.74865 16.7742 2.58065 16.7742C2.58065 16.4409 2.58065 4.39389 2.58065 2.58064H12.9032V12.219C13.6811 11.8314 14.5574 11.6129 15.4839 11.6129V0H0V21.9355H11.8388C10.3001 20.6912 9.49265 18.7622 9.71346 16.7742ZM6.45161 19.3548H2.58065V18.0645H6.45161V19.3548Z"
                                                fill="#FFB224" />
                                            <path d="M3.87091 6.45142H5.16123V7.74174H3.87091V6.45142Z" fill="#FFB224" />
                                            <path d="M3.87091 3.87085H5.16123V5.16117H3.87091V3.87085Z" fill="#FFB224" />
                                            <path d="M3.87091 11.6128H5.16123V12.9031H3.87091V11.6128Z" fill="#FFB224" />
                                            <path d="M3.87091 9.03223H5.16123V10.3225H3.87091V9.03223Z" fill="#FFB224" />
                                            <path d="M3.87091 14.1934H5.16123V15.4837H3.87091V14.1934Z" fill="#FFB224" />
                                            <path
                                                d="M15.4838 12.9031C12.9936 12.9031 10.9677 14.929 10.9677 17.4192C10.9677 19.9094 12.9936 21.9353 15.4838 21.9353C17.974 21.9353 20 19.9094 20 17.4192C20 14.929 17.974 12.9031 15.4838 12.9031ZM15.4838 20.13L13.1905 18.6011L13.9063 17.5275L14.8387 18.1492V14.8386H16.129V18.1492L17.0615 17.5276L17.7773 18.6012L15.4838 20.13Z"
                                                fill="#FFB224" />
                                        </svg><span class="font-size-14">Download Invoice</span>
                                    </a>
                                    <?php endif; ?>
                        </div>
                    </div>
                    <div class="card border-shadow">

                        <div class="card-body">
                            <div class="border-bottom">
                                <div class="d-flex justify-content-between">
                                    <span class="fw-bold font-size-15">Trip Booking Id: #<?php echo e($data->id); ?></span>
                                    <a href="<?php echo e(route('mytrip')); ?>" class="fw-bold">
                                        < Back <span class="curent-tier">to Trips History</span> </a>
                                </div>
                            </div>

                            <div class="row mt-4">
                                <div class="col-md-6 pe-3">
                                    <p class="fw-bold text font-size-14"><u>Trip Name</u></p>
                                    <h5 class="fw-bold text font-size-18"><?php echo e($data->trip->name); ?></h5>
                                    <div class="trip-dates">
                                        <div class="row">
                                            <div class="col-xl-6 col-lg-12 col-md-12 col-12">
                                                <span class="font-size-12">Trip Start Date:</span><span class="fw-bold font-size-12"> &nbsp; <?php echo e(date('d M ,Y', strtotime($data->trip->start_date))); ?></span>

                                            </div>
                                            <div class="col-xl-6 col-lg-12 col-md-12 col-12">
                                                <span class="font-size-12">Trip End Date:</span><span class="fw-bold font-size-12"> &nbsp; <?php echo e(date('d M ,Y', strtotime($data->trip->end_date))); ?>

                                                    </span>
                                            </div>
                                        </div>


                                    </div>
                                    <?php
                                        $firstTraveler = json_decode($data->customer_id)[0];
                                        $travelerOne = getCustomerById($firstTraveler);
                                    ?>
                                    <h6 class="fw-bold text mt-2 font-size-14"><?php echo e($travelerOne->name); ?></h6>
                                    <div class="trip-dates font-size-14">
                                        <p><?php echo e($travelerOne->address . ', ' . $travelerOne->city . ', ' . $travelerOne->state . ', ' . $travelerOne->pincode . ', ' . $travelerOne->country); ?>

                                        </p>
                                    </div>
                                    <h6 class="fw-bold text mt-2 font-size-14">Phone number</h6>
                                    <div class="trip-dates font-size-14">
                                        <p><?php echo e($travelerOne->phone); ?></p>
                                    </div>
                                    <h6 class="fw-bold text mt-2 font-size-14">Email</h6>
                                    <div class="trip-dates font-size-14">
                                        <p><?php echo e($travelerOne->email); ?></p>
                                    </div>
                                </div>
                                <div class="col-md-4 mx-auto d-block">
                                    <p class="fw-bold text font-size-14"><u>Your Reward</u></p>
                                    <div>
                                        <img src="<?php echo e(asset('public/userpanel')); ?>/asset/images/star.svg" alt="">
                                        <span class="text fw-bold information-trip-count"
                                            style="font-size: 22px"><?php echo e($travelerOne->points); ?></span>
                                        <small class="font-size-12">Points</small><br>
                                        <small class="">Expiring on: 26th Jan, 2023</small>
                                    </div>
                                    <div class="mt-4">
                                        <h5 class="text fw-bold font-size-14"><u>Trip Members Details (Minors Details)</u>
                                        </h5>
                                        <?php $__currentLoopData = json_decode($data->customer_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $c_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $travelers = getCustomerById($c_id);
                                        ?>
                                        <span class="fw-bold text font-size-14">Traveler
                                            <?php echo e($key + 1); ?> <?php if($travelers->parent > 0): ?>
                                                (Minor)
                                            <?php endif; ?>
                                            :</span><span>&nbsp;<?php echo e($travelers->name); ?>

                                            (<?php echo e($travelers->relation); ?>, <?php echo e(getYearsFromDob($travelers->dob)); ?>

                                            yrs)
                                        </span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class="mt-4">
                                        <h5 class="text fw-bold font-size-14">Room Type</h5>
                                        <h5 class="text fw-bold font-size-14"><?php echo e($data->room_type); ?></h5>
                                    </div>
                                </div>
                                <div class="col-md-2 d-none d-md-block">
                                    <p class="fw-bold text font-size-14"><u>More actions</u></p>
                                    <?php if(isset($data->invoice_file)): ?>
                                    <a href="<?php echo e(env('ADMIN_URL').$data->invoice_file); ?>" target="_blank">

                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="22"
                                            viewBox="0 0 20 22" fill="none">
                                            <path d="M6.45166 6.45142H11.613V7.74174H6.45166V6.45142Z" fill="#FFB224" />
                                            <path d="M6.45166 9.03223H11.613V10.3225H6.45166V9.03223Z" fill="#FFB224" />
                                            <path d="M6.45166 3.87085H11.613V5.16117H6.45166V3.87085Z" fill="#FFB224" />
                                            <path
                                                d="M6.45166 15.4838H10.0096C10.3381 14.5575 10.8952 13.7386 11.613 13.0954V11.6128H6.45166V15.4838Z"
                                                fill="#FFB224" />
                                            <path
                                                d="M9.71346 16.7742C7.49265 16.7742 4.74865 16.7742 2.58065 16.7742C2.58065 16.4409 2.58065 4.39389 2.58065 2.58064H12.9032V12.219C13.6811 11.8314 14.5574 11.6129 15.4839 11.6129V0H0V21.9355H11.8388C10.3001 20.6912 9.49265 18.7622 9.71346 16.7742ZM6.45161 19.3548H2.58065V18.0645H6.45161V19.3548Z"
                                                fill="#FFB224" />
                                            <path d="M3.87091 6.45142H5.16123V7.74174H3.87091V6.45142Z" fill="#FFB224" />
                                            <path d="M3.87091 3.87085H5.16123V5.16117H3.87091V3.87085Z" fill="#FFB224" />
                                            <path d="M3.87091 11.6128H5.16123V12.9031H3.87091V11.6128Z" fill="#FFB224" />
                                            <path d="M3.87091 9.03223H5.16123V10.3225H3.87091V9.03223Z" fill="#FFB224" />
                                            <path d="M3.87091 14.1934H5.16123V15.4837H3.87091V14.1934Z" fill="#FFB224" />
                                            <path
                                                d="M15.4838 12.9031C12.9936 12.9031 10.9677 14.929 10.9677 17.4192C10.9677 19.9094 12.9936 21.9353 15.4838 21.9353C17.974 21.9353 20 19.9094 20 17.4192C20 14.929 17.974 12.9031 15.4838 12.9031ZM15.4838 20.13L13.1905 18.6011L13.9063 17.5275L14.8387 18.1492V14.8386H16.129V18.1492L17.0615 17.5276L17.7773 18.6012L15.4838 20.13Z"
                                                fill="#FFB224" />
                                        </svg><span class="font-size-14">Download Invoice</span>
                                    </a>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-10 border-top pt-2 table-responsive">
                                    <table  class="table border-0">
                                        <tr>
                                            <th scope="col">Lead Source</th>
                                            <th scope="col">Vehicle Type</th>
                                            <th scope="col">Vehicle Seat</th>
                                            <th scope="col">Room Type</th>
                                            <th scope="col">Room Category</th>
                                        </tr>

                                       <tr>
                                        <td><?php echo e($data->lead_source); ?>, <?php echo e($data->sub_lead_source); ?></td>
                                        <td><?php echo e($data->vehical_type); ?></td>
                                        <td><?php echo e($data->vehical_seat); ?></td>
                                        <td><?php echo e($data->room_type); ?></td>
                                        <td><?php echo e($data->room_cat); ?></td>
                                    </tr>
                                    </table>
                                   
                                </div>
                            </div>

                        </div>
                    </div>

                    <div class="card border-shadow mt-3 pb-5">
                        <div class="card-body">
                            <div class="col-md-10 col-12">
                                <h6 class="text fw-bold ">Summary</h6>
                                <div class="row mt-5">
                                    <div class="col-md-6">

                                        <div class="border-bottom">
                                            <h6 class="fw-bold text">Trip Cost</h6>
                                            <div id="trip_cost">

                                            </div>
                                        </div>

                                        <div class="border-bottom mt-3">
                                            <h6 class="fw-bold text font-size-14">Extra Services</h6>
                                            <div id="extra_service_data">

                                            </div>
                                        </div>
                                        <div class="tax mt-3 border-bottoms pb-2">
                                           <div id="tax_info">

                                           </div>
                                        </div>

                                        <div class="mt-3 pb-2 border-bottoms">
                                            <div class="d-flex justify-content-between">
                                                <span class="fw-bold text  font-size-12">Total Trip Cost</span>

                                                <h6 class="font-size-14" id="total_trip_cost_amt">0</h6>
                                            </div>
                                        </div>

                                        <div class="mt-3 pb-2 border-bottoms">
                                             <span class="fw-bold text font-size-14">Points Redeemed</span><br>
                                            <div id="redeem_points_list">

                                            </div>
                                        </div>

                                        <div class="mt-3 pb-2 border-bottoms">
                                            <div class="d-flex justify-content-between">
                                                <span class="fw-bold text font-size-14">Total Payable Amount</span>

                                                <h6 class="font-size-12" id="total_payable_amt">0</h6>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="col-md-6 payment-details">
                                        <div class="border-bottoms pb-3">
                                            <h6 class="fw-bold text font-size-14">Payments Detail</h6>
                                            <div id="payment_details_list">

                                            </div>
                                            

                                        </div>
                                        <div class="mt-3 pb-2 border-bottoms">
                                            <div class="d-flex justify-content-between">
                                                <span class="fw-bold text font-size-14">Total Amount Received</span>

                                                <h6 class="font-size-14" id="total_rec_amt">0</h6>
                                            </div>
                                        </div>

                                        <div class="d-flex justify-content-between mt-2">
                                            <div>
                                                <span class="fw-bold text font-size-14">Points Earned</span><br>
                                                <span class="gray font-size-12">1% of total paid amount </span>
                                            </div>
                                            <h6 class="font-size-14" id="earning_pts">0</h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                    <?php echo $__env->make('imp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script>
    // Create our number formatter.
    const formatter = new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'INR',
    });


    $(document).ready(function() {
        getSummary();
    });


    function getSummary() {
        $.ajax({
            url: "<?php echo e(route('summary')); ?>",
            type: "POST",
            data: {
                "_token": "<?php echo e(csrf_token()); ?>",
                token: "<?php echo e(request()->token); ?>",
            },
            success: function(res) {
                if (!res) {
                    alert("Somthing Went Wrong, try again.")
                } else {
                    var data = JSON.parse(res);
                    var trip_costs = data.trip_costs;
                    var extra_services = data.extra_services;
                    var taxes = data.taxes;
                    var points = data.points;
                    var payment = data.advance_payment;
                    var partPayment = data.part_payment;

                    var total_trip_cost = 0;
                    var total_redeem_amt = 0;
                    var total_payable_amt = 0;
                    var total_rcvd_amt = 0;

                    var trip_cost_list = "";
                    var extra_service_list = `<h6 class="fw-bold text font-size-14">Extra Services</h6>`;
                    var tax_list = `<h6 class="fw-bold text font-size-14">Tax</h6>`;
                    var redeem_poins_data = "";
                    var final_paid = "";

                    // trip cost
                    $.each(trip_costs, function(key, value) {
                        total_trip_cost += parseInt(value.cost);

                        var isParent = "";
                        if (value.parent > 0) {
                            isParent = "(Minor)";
                        }
                        trip_cost_list += `<div class="d-flex justify-content-between">
                                                    <p class="gray font-size-12">Traveler ${ key + 1 }
                                                        (${value.traveler})  ${isParent}
                                                        <span data-bs-toggle="tooltip" data-bs-placement="right"
                                                            title="Vehicle Amount = ${formatter.format(value.vehicle_amt)} , Room Amount = ${formatter.format(value.room_amt)} ">
                                                            <img src="<?php echo e(asset('public/userpanel')); ?>/asset/images/hover.svg"
                                                                alt="" class="ps-2">
                                                        </span>
                                                    </p>
                                                    <h6 class="font-size-14">${formatter.format(value.cost)}
                                                    </h6>
                                                </div>`;
                    });
                    $("#trip_cost").html(trip_cost_list);
                    // trip cost

                    // extra_service_list
                    $.each(extra_services, function(key, value) {
                        total_trip_cost += parseInt(value.extra_charges);
                        extra_service_list += `<div class="d-flex justify-content-between">
                                                    <p class="gray font-size-12"> ${value.services} for ${value.traveler_name}<span
                                                            data-bs-toggle="tooltip" data-bs-placement="right"
                                                            title="Net Cost = ${formatter.format(value.amount)}, Markup = ${formatter.format(value.markup)}, Tax = ${value.tax}%">
                                                            <img src="<?php echo e(asset('public/userpanel')); ?>/asset/images/hover.svg"
                                                                alt="" class="ps-2">
                                                        </span></p>
                                                    <h6 class="font-size-14">+${formatter.format(value.extra_charges)}</h6>
                                                </div>`;
                    });
                    $("#extra_service_data").html(extra_service_list);
                    // extra_service_list

                    // tax
                    $.each(taxes.gst, function(key, value) {
                        total_trip_cost += parseInt(value.gst);
                        tax_list += `<div class="d-flex justify-content-between mt-2">
                                        <div>
                                            <span class="fw-bold text  font-size-14">GST ${value.gst_per}%</span><br>
                                            <span class="gray font-size-12"> ${value.traveler}</span>
                                        </div>
                                        <h6 class="font-size-14">+${formatter.format(value.gst)}</h6>
                                    </div>`;
                    });
                    $.each(taxes.tcs, function(key, value) {
                        total_trip_cost += parseInt(value.tcs);
                        tax_list += `<div class="d-flex justify-content-between mt-2">
                                        <div>
                                            <span class="fw-bold text  font-size-14">TCS ${value.tcs_per}%</span><br>
                                            <span class="gray font-size-12"> ${value.traveler}</span>
                                        </div>
                                        <h6 class="font-size-14">+${formatter.format(value.tcs)}</h6>
                                    </div>`;
                    });
                    $("#tax_info").html(tax_list);
                    // tax

                    // redeem points
                    $.each(points, function(key, value) {
                        total_redeem_amt += parseInt(value.points);
                        redeem_poins_data += `<div class="d-flex justify-content-between">
                                                <span class="gray font-size-12"> ${value.traveler} </span>
                                                <h6 class="font-size-12">-${formatter.format(value.points)}</h6>
                                            </div>`;
                    });
                    $("#redeem_points_list").html(redeem_poins_data);
                    // redeem points

                    // payment
                    if (payment.payment) {
                        total_rcvd_amt += parseInt(payment.payment);
                        final_paid += `<div class="d-flex justify-content-between">
                                                    <div>
                                                        <span class="fw-bold text font-size-14">Advance Payment
                                                            <span data-bs-toggle="tooltip"
                                                                data-bs-placement="right"
                                                                title="First Advance payment of Total payable amount">
                                                                <img src="<?php echo e(asset('public/userpanel')); ?>/asset/images/hover.svg"
                                                                    alt="" class="ps-2">
                                                            </span></span><br>
                                                        <span class="gray font-size-12"> Received on ${payment.date}
                                                        </span>
                                                    </div>
                                                    <h6 class="font-size-14">${formatter.format(payment.payment)}</h6>
                                                </div>`;

                        $.each(partPayment, function(key, value) {
                            total_rcvd_amt += parseInt(value.amount);
                            final_paid += `<div class="d-flex justify-content-between mt-1">
                                                    <div>
                                                        <span class="fw-bold text font-size-14">Payment ${key+1}
                                                            <span data-bs-toggle="tooltip"
                                                                data-bs-placement="right"
                                                                title="${value.remark == "Other" ? value.comment : value.remark}">
                                                                <img src="<?php echo e(asset('public/userpanel')); ?>/asset/images/hover.svg"
                                                                    alt="" class="ps-2">
                                                            </span></span><br>
                                                        <span class="gray font-size-12"> Received on ${value.date}
                                                        </span>
                                                    </div>
                                                    <h6 class="font-size-14">${formatter.format(value.amount)}</h6>
                                                </div>`;
                        });

                        $("#total_rec_amt").text(formatter.format(total_rcvd_amt));
                        $("#payment_details_list").html(final_paid);
                    }
                    // payment

                    // total amount
                    $("#total_trip_cost_amt").text(formatter.format(total_trip_cost))

                    // total
                    total_payable_amt = parseInt(total_trip_cost) - parseInt(total_redeem_amt);
                    $("#total_payable_amt").text(formatter.format(total_payable_amt));
                    $("#payable_amt_to_saved").val(total_payable_amt);
                    // points
                    earning_pts = total_payable_amt * 1 / 100;
                    $("#earning_pts").text(Math.round(earning_pts));
                }
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.userlayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\freelance\ao-new\resources\views/trip-details.blade.php ENDPATH**/ ?>