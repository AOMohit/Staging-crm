<div class="card-header-top col-12">
    <div class="d-flex justify-content-center laptop">
        
        <span class="bg-white shadows rounded p-2  information-trip mx-2">
            <span class="text"><span class="curent-tier">Total</span> Trips:</span> <span
                class="text fw-bold information-trip-count"><?php echo e(count(tripCount())); ?></span>
        </span>
        
        
        <span class="bg-white shadows rounded p-2  information-trip mx-2">
            <span class="text"> <span class="curent-tier"> The Current </span> Tier:</span> <span
                class="text fw-bold information-trip-count"><?php echo e(Auth::user()->tier); ?></span>
        </span>
        
        
        <span class="bg-white shadows rounded p-2 information-trip mx-2">
            <span class="text"><span class="curent-tier"> You have total:</span></span>
            <img src="<?php echo e(asset('public/userpanel')); ?>/asset/images/star.svg" alt="">
            <span class="text fw-bold information-trip-count"><?php echo e(Auth::user()->points); ?></span>
            <small>Points</small>
            <small class="expiring-point">Expiring on: 26th Jan, 2023</small>
        </span>
        


    </div>
    <div class="mobile">
        <div class="row">
            <div class="col-6 header-card-data ">
                <div class="bg-white shadows rounded p-2  information-trip mx-2 text-center">
                    <span class="text"><span class="curent-tier">Total</span> Trips:</span> <span
                        class="text fw-bold information-trip-count">100</span>
                </div>
            </div>
            <div class="col-6 header-card-data ">
                <div class="bg-white shadows rounded p-2  information-trip mx-2 text-center">
                    <span class="text"> <span class="curent-tier"> The Current </span> Tier:</span> <span
                        class="text fw-bold information-trip-count"><?php echo e(Auth::user()->tier); ?></span>
                </div>
            </div>
            <div class="col-12 header-card-data text-center w-100">
                <div class="bg-white shadows rounded p-2 information-trip mx-2">
                    <span class="text"><span class="curent-tier"> You have total:</span></span>
                    <img src="<?php echo e(asset('public/userpanel')); ?>/asset/images/star.svg" alt="">
                    <span class="text fw-bold information-trip-count"><?php echo e(Auth::user()->points); ?></span>
                    <small>Points</small>
                    <small class="expiring-point">Expiring on: 26th Jan, 2023</small>
                </div>
            </div>


        </div>
    </div>

</div>
<?php /**PATH C:\xampp\htdocs\freelance\final project\ao-new\resources\views/layouts/userlayout/card-header.blade.php ENDPATH**/ ?>