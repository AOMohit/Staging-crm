</div>
</div>
</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.0/js/toastr.js"></script>
<script>
    function getTripPrice(value){
       $.ajax({
                url: "<?php echo e(route('getPrice')); ?>",
                method: "POST",
                data: {
                   value:value,
                   
                    _token: "<?php echo e(csrf_token()); ?>"

                },
                success: function(responce) {
                //   alert(responce);
                    $('#trip-price').text(responce);
                    $('#total-price').text(responce);
                    $('#trip-prices').val(responce);
                    
                }
               
            });
    }
</script>
    <script>
        <?php if(Session::has('message')): ?>
            toastr.options = {
                "closeButton": true,
                "progressBar": true
            }
            toastr.success("<?php echo e(session('message')); ?>");
        <?php endif; ?>

        <?php if(Session::has('error')): ?>
            toastr.options = {
                "closeButton": true,
                "progressBar": true
            }
            toastr.error("<?php echo e(session('error')); ?>");
        <?php endif; ?>

        <?php if(Session::has('info')): ?>
            toastr.options = {
                "closeButton": true,
                "progressBar": true
            }
            toastr.info("<?php echo e(session('info')); ?>");
        <?php endif; ?>

        <?php if(Session::has('warning')): ?>
            toastr.options = {
                "closeButton": true,
                "progressBar": true
            }
            toastr.warning("<?php echo e(session('warning')); ?>");
        <?php endif; ?>
    </script>
<script>
    function changeValue(type) {
        var val = $('#adultvalue').val();
        if (val >= 0) {
            if (type == 'plus') {
                var total = parseInt(val) + 1;
            } else {
                var total = parseInt(val) - 1;
            }
        } else {
            var total = 0;
        }
        $('#adultvalue').val(total);

        var child = $('#childvalue').val();
        var tripprice = $('#trip-prices').val();
        var traveler = parseInt(total) + parseInt(child);

        var total_price = parseInt(tripprice)* parseInt(traveler);

        $('.totalTravel').text(traveler);
        $('#price').val(total_price);
        $('#total-price').text(total_price);
        $('#adult-count').text(total);
        $('#child-count').text(child);



    }

    function changeValueChild(type) {
        var val = $('#childvalue').val();
        if (val >= 0) {
            if (type == 'plus') {
                var total = parseInt(val) + 1;
            } else {
                var total = parseInt(val) - 1;
            }
        } else {
            var total = 0;
        }
        $('#childvalue').val(total);

        var adult = $('#adultvalue').val();
         var tripprice = $('#trip-prices').val();
        var traveler = parseInt(total) + parseInt(adult);
        var total_price = parseInt(tripprice)* parseInt(traveler);

        $('.totalTravel').text(traveler);
        $('#price').val(total_price);
        $('#total-price').text(total_price);
        $('#adult-count').text(adult);
        $('#child-count').text(total);


    }

    function openModal(){
         var adult = $('#adultvalue').val();
         var child = $('#childvalue').val();

         

    }
  
</script>

</body>

</html><?php /**PATH /home/u989572071/domains/deweca.com/public_html/ao/resources/views/layouts/userlayout/footer.blade.php ENDPATH**/ ?>