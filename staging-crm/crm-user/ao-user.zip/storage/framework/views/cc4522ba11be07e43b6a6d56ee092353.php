
<?php $__env->startSection('container'); ?>

<div class="col-md-10 col-12">
    <div class="border-shadow mb-4">
        <div class="card">
            <div class="card-header bg-white information">
                 <?php echo $__env->make('layouts.userlayout.card-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="card-body">
                <h6 class="text fw-bold mb-3">How to Redeem Points</h6>

                <div class="card border-shadow pb-4 ">
                    <div class="text-center mt-4 total-earning-card">
                        
                          <span class=" rounded shadows bg-white p-3 ">

                                <span class="font-size-14 font-size-mobile-14 fw-bold text"> You Have Total</span>
                                &nbsp; <img src="<?php echo e(asset('public/userpanel')); ?>/asset/images/star.svg" alt="">
                                <span class="fw-bold font-size-20 font-size-mobile-20"><?php echo e(Auth::user()->points); ?></span>
                                <small class="font-size-10 font-size-mobile-10">Points</small>
                                &nbsp; <small class="font-size-9 font-size-mobile-9">Expiring on: 26th Jan, 2023</small>

                            </span>
                    </div>
                    <div class="text-center mt-4">
                        <small class="fw-bold green background-3 rounded p-2 px-3 point-text font-size-12">Your total points are 5000, which is equal to Rs. 5000 (1 point = Rs. 1)</small>
                    </div>

                    <div class="col-md-12 p-3">
                        <form action="<?php echo e(route('enquirySubmit')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" value="redeem" name="type">
                            <div class="row">
                                <div class="col-md-3 col-12 redeem-form">
                                    <label for="">Choose Expeditions <span class="red">*</span></label> <br>
                                    <select name="expedition" class="w-100 mt-2" id="" required onchange="getTripPrice(this.value)">
                                        <option value="">—Please choose an option—</option>
                                        <?php $__currentLoopData = $trip; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trips): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            
                                        <option value="<?php echo e($trips->id); ?>"><?php echo e($trips->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <option value="0">Other</option>

                                        
                                    </select>

                                </div>
                                <div class="col-md-3 col-12 redeem-form">
                                    <label for="">Total Available Points </label> <br>
                                    <div class="border rounded information-trip mt-2 py-2 ps-1">
                                        <!-- <span class="text">You have total:</span> -->
                                        <img src="<?php echo e(asset('public/userpanel')); ?>/asset/images/star.svg" alt="">
                                        <span class="text fw-bold ps-6"><?php echo e(Auth::user()->points); ?></span>
                                        <small>Points</small>
                                        <small class="expiring">Expiring on: 26th Jan, 2023</small>
                                    </div>
                                </div>
                                <div class="col-md-4 col-12 redeem-form">
                                    <label for="">How many points you want to redeem <span class="red">*</span></label> <br>
                                    <input type="text" name="redeem_points" class="form-control mt-2" id="" placeholder="Enter Point">
                                </div>
                                <div class="col-md-2 col-12 redeem-form">
                                    <label for=""> </label><br>

                                    <button class="button p-2 px-2 mt-2">Redeem Points</button>
                                </div>
                            </div>
                        </form>
                        <div class="mt-2">
                            <small class="text-secondary">Trip Cost: ₹ <span id="trip-price">0</span></small>
                        </div>
                    </div>

                    <div class="p-4">
                        <h6 class="text fw-bold"><?php echo setting('redeem_points_title'); ?></h6>
                       <?php echo setting('redeem_points'); ?>

                    </div>

                </div>

            </div>
            <div class=" px-4">
<?php echo $__env->make('imp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>

            
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.userlayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u679865197/domains/adventuresoverland.com/public_html/crm-user/resources/views/remeed-point.blade.php ENDPATH**/ ?>