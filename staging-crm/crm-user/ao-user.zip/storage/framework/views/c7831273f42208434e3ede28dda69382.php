<?php echo $__env->make('layouts.userlayout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('container'); ?>

<?php echo $__env->make('layouts.userlayout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/codesgro/ao.codesground.com/resources/views/layouts/userlayout/index.blade.php ENDPATH**/ ?>