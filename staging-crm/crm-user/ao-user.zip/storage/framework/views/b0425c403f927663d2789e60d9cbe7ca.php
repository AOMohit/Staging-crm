<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fira+Sans:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Geologica:wght@100;300&family=Lato&family=Open+Sans&family=Poppins&family=Roboto&display=swap" rel="stylesheet">
   <style>
        @font-face {
          font-family: 'Fira Sans ';
          src: url('https://fonts.googleapis.com/css2?family=Fira+Sans:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap')

          font-weight: normal;
          font-style: normal;
        }
        body{
            background-color: #FFF8EA;
            font-family: Fira Sans;

        }
        .container{
            padding-block: 40px;
        }
        .col-10{
            background-color:white; 
            width:640px ;height:530px;
            border-radius: 10px;
            padding: 30px;
            align-items: center;
            
            
        }
        .item-center{
            margin-inline: auto;
        }
        .border{
            border-bottom: #D2E8FF solid 2px;
            width:700px;
            padding-top:20px;
        }
        .h6{
            text-align: center;
            font-size: 14px;
        }
        .p{
            margin-top: 10px;
            text-align: center;
            font-size: 12px;
        }
        .button-div{
            margin-top: 50px;
        }
        .button{
            
            background-color: #FFB224;
            text-decoration: none;
            color: white;
            padding: 10px;
            border-radius: 10px;
        }
   </style>
</head>
<body style=" background-color: #FFF8EA;font-family: Fira Sans;padding-top:40px;padding-bottom:40px;">
    <table style="margin-left:auto;margin-right:auto">
        <thead>
            <th><img src="<?php echo e(env('ADMIN_URL').'storage/app/'.setting('logo')); ?>" style="width:auto;height:56px"><th>
        </thead>
   </table>
    
    <div class="container">
        <div class="col-10 " style="background-color:white; width:640px ;height:auto;border-radius: 10px;padding: 30px;margin-left:auto;margin-right:auto;">
            <div class="row mb-3">
            
                <p style="font-family: 'Fira Sans', sans-serif;font-weight:400">Hi <?php echo e($mailData['first_name']); ?> <?php echo e($mailData['last_name']); ?>,</p>
                <p style="font-family: 'Fira Sans', sans-serif;font-weight:400">
                    Thank you for your enquiry. Someone from our team will get back to you very soon.
                </p>

            </div>
            
            </div>
        </div>

        <div class="border item-center" style="border-bottom:#D2E8FF solid 2px;width:700px;padding-top:20px;margin-left:auto;margin-right:auto;">

        </div>
       
        <div class="item-center">
            
                 <h6 class="h6" style="text-align: center;font-family: 'Fira Sans', sans-serif;
            font-size: 14px;">
                    © 2024 Adventures Overland Pvt Ltd., All Rights Reserved.<br>
                1023, Tower B4, 10th Floor, Spaze IT Tech Park, Sohna Road, Gurugram, Haryana-122018 
                </h6>
                <p class="p" style="margin-top: 10px;font-family: 'Fira Sans', sans-serif;
            text-align: center;
            font-size: 12px;">
                    This email was sent to <?php echo e($mailData['email']); ?> . If you dont want to recieve these emails fom Adventures Overland in the future, please <br> unsubscribe from Adventures Overland Platform. <br>To help secure your account, please dont forward this email.</p>
            
        </div>
    </div>
</body>
</html><?php /**PATH /home/u989572071/domains/deweca.com/public_html/ao/resources/views/emails/enquiry.blade.php ENDPATH**/ ?>