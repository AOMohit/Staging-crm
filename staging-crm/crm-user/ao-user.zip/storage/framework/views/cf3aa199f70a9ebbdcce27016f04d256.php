
<?php $__env->startSection('container'); ?>
    <div class="col-md-10 col-12">
        <div class="border-shadow mb-4">
            <div class="card px-3">
                <div class="card-header bg-white information">
                    <?php echo $__env->make('layouts.userlayout.card-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <h6 class="text fw-bold mb-4 mt-3">Enquire for a Trip</h6>

                <div class="card border-shadow">
                    <div class="card-body">

                        <div class="container">
                            <div class="col-12">
                                <form action="<?php echo e(route('enquirySubmit')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-5 col-12 redeem-form ">
                                            <div class="mt-3">

                                                <label for="">Choose your Expedition <span>*</span></label><br>
                                                <select name="expedition" id="" class="border" required onchange="getTripPrice(this.value)">
                                                    <option value="">—Please choose an option—</option>
                                                    <?php $__currentLoopData = $trip; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trips): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($trips->id); ?>"><?php echo e($trips->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </select>
                                            </div>

                                            <div class="mt-4">
                                                <label for="">Add Travelers <span>*</span></label><br>
                                                <div class="row mt-4">
                                                    <div class="col-6 enquiry ">
                                                        <label for="" class="text-secondary ">Adults - Above 12
                                                            Years</label>
                                                        <div class=" borders mt-2">
                                                            <span onclick="changeValue('minus')">-</span>
                                                            <input type="text" name="adult" value="1"
                                                                onchange="totalinput(this.value)" id="adultvalue">
                                                            <span onclick="changeValue('plus')">+</span>
                                                        </div>

                                                    </div>
                                                    <div class="col-6 enquiry ">
                                                        <label for="" class="text-secondary ">Children - Below 12
                                                            Years</label>
                                                        <div class=" borders mt-2">
                                                            <span onclick="changeValueChild('minus')">-</span>
                                                            <input type="text" name="minor" value="0"
                                                                onchange="totalinput(this.value)" id="childvalue">
                                                            <span onclick="changeValueChild('plus')">+</span>
                                                        </div>

                                                    </div>

                                                </div>
                                            </div>

                                            <div class="mt-4">


                                                <span class=""><span class ="totalTravel">1</span> Travelers - <span
                                                        id ="adult-count">1</span> Adults, <span id ="child-count">0</span>
                                                    Child</span><br>

                                                <a href="javascript:void(0)" onclick="addTravelerModal()"
                                                    class="blue fw-bold">Add Travelers Details</a>

                                            </div>


                                            <input type="hidden" name="travelerListJson" id="travelerListJson"
                                                value="">
                                            <div class="mt-4 pe-3" id="traveler-final-list">



                                            </div>

                                        </div>
                                        <div class="col-md-7 col-12 border-start">
                                            <div class=" p-4">

                                                <span class="fw-bold">Your Total Available Points</span>
                                                <div class="col-md-7 col-12 mt-3 mb-3 ">
                                                    <div class="bg-white shadows rounded p-2 px-1 information-trip">

                                                        <img src="<?php echo e(asset('public/userpanel')); ?>/asset/images/star.svg"
                                                            alt="">
                                                        <span class="text fw-bold information-trip-count"><?php echo e(Auth::user()->points); ?></span>
                                                        <small>Points</small>
                                                        <small>Expiring on: 26th Jan, 2023</small>
                                                    </div>

                                                </div>
                                                <span class="fw-bold">Would you like to redeem your points?</span>

                                                <div class="redeem-form">
                                                    <select name="redeem_points_status" class="w-25 mt-2" id=""
                                                        required>

                                                        <option value="yes">Yes</option>
                                                        <option value="no">No</option>
                                                    </select>
                                                </div>
                                                <div class="col-md-8">
                                                    <div class="d-flex justify-content-between mt-4">
                                                        <div>
                                                            <span>Total Trip Cost</span><br>
                                                            <small class="text-secondary">₹ <span id="trip-price">0</span> x <span
                                                                    class="totalTravel">1</span> Travelers</small>
                                                            <input type="hidden" name="" id="trip-prices">
                                                        </div>
                                                        <input type="hidden" name="price" id='price'><span
                                                            class="fw-bold" >₹ <span id="total-price">0</span></span>
                                                    </div>

                                                </div>
                                                <p class="text-secondary mt-5">
                                                    By clicking on the Book Now button below to proceed with the booking, I
                                                    confirm that I have read and I accept Cancellation Policy, User
                                                    Agreement, Terms of Service and Privacy Policy of Adventures Overland.


                                                </p>

                                                <button class="button px-5 p-2">Enquire Now</button>

                                                <!-- modal for traveller add -->

                                            </div>
                                        </div>
                                    </div>
                                </form>
                                <div class="modal fade" id="travelers" data-bs-backdrop="static" data-bs-keyboard="false"
                                    tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                    <div class="modal-dialog rounded modal-lg">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h6 class="modal-title" id="staticBackdropLabel">Add Traveler
                                                    Details</h6>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="col-md-12 p-2">

                                                    <!--<form action="">-->
                                                    <div class="radio-toolbar" id="traveler-radio-list">


                                                        <!-- <small class="text-secondary">3 years old</small> -->
                                                    </div>
                                                    <div class="row mt-5">
                                                        <div class="col-md-4 col-12 redeem-form">
                                                            <label for="">Full Name<span
                                                                    class="red">*</span></label> <br>
                                                            <input type="text" name=""
                                                                class="form-control mt-2" id="traveler-name"
                                                                placeholder="Enter Name">
                                                        </div>
                                                        <div class="col-md-4 col-12 redeem-form">
                                                            <label for="">Date of Birth<span
                                                                    class="red">*</span></label> <br>
                                                            <input type="date" name=""
                                                                class="form-control mt-2" id="traveler-dob"
                                                                placeholder="Enter Piont">
                                                        </div>
                                                        <div class="col-md-3 col-12 redeem-form">
                                                            <label for="">Gender <span
                                                                    class="red">*</span></label> <br>
                                                            <select name="" class="w-100 mt-2"
                                                                id="traveler-gender">

                                                                <option value="Male">Male</option>
                                                                <option value="Female">Female</option>
                                                            </select>

                                                        </div>
                                                        <button onclick="addTraveler()"
                                                            class="button px-5 mt-3 p-2 w-50">Add
                                                            Traveler</button>

                                                    </div>
                                                    <!--</form>-->
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

<div class="modal fade" id="travelersEdit" data-bs-backdrop="static" data-bs-keyboard="false"
                                    tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                    <div class="modal-dialog rounded modal-lg">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h6 class="modal-title" id="staticBackdropLabel">Edit Traveler
                                                    Details</h6>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="col-md-12 p-2">

                                                   
                                                    <div class="row mt-5">
                                                        <div class="col-md-4 col-12 redeem-form">
                                                            <label for="">Full Name<span
                                                                    class="red">*</span></label> <br>
                                                            <input type="text" name=""
                                                                class="form-control mt-2" id="traveler-name-edit"
                                                                placeholder="Enter Name">
                                                        </div>
                                                        <div class="col-md-4 col-12 redeem-form">
                                                            <label for="">Date of Birth<span
                                                                    class="red">*</span></label> <br>
                                                            <input type="date" name=""
                                                                class="form-control mt-2" id="traveler-dob-edit"
                                                                placeholder="Enter Piont">
                                                        </div>
                                                        <div class="col-md-3 col-12 redeem-form">
                                                            <label for="">Gender <span
                                                                    class="red">*</span></label> <br>
                                                            <select name="" class="w-100 mt-2"
                                                                id="traveler-gender-edit">

                                                                <option value="Male">Male</option>
                                                                <option value="Female">Female</option>
                                                            </select>

                                                        </div>
                                                        <button onclick="addTraveler()"
                                                            class="button px-5 mt-3 p-2 w-50">Add
                                                            Traveler</button>

                                                    </div>
                                                    <!--</form>-->
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>


                <!-- important note -->
                <div class="mt-5 important-note px-4">

                    <h6 class="text fw-bold">Important Note:</h6>
                    <ul class="mt-5">
                        <li>Points earned in the Adventures Overland Loyalty Programme are transferable between members.
                        </li>
                        <li>To initiate a points transfer, both the sender and recipient must confirm the transaction
                            through their respective accounts.</li>
                        <li>Transferred points retain their original value and can be used for bookings, discounts, and
                            other eligible rewards.</li>
                        <li>Adventures Overland reserves the right to impose reasonable limits on the frequency and quantity
                            of point transfers.</li>
                        <li>The transfer feature is designed to enhance the flexibility of the loyalty programme and foster
                            a sense of community among our members.</li>
                        <li>Any attempted misuse or fraudulent activity related to points transfer may result in the
                            suspension of the involved accounts.</li>
                    </ul>

                </div>

                <div class="p-3 term-condition">
                    <a href="#">Terms & Conditions <svg xmlns="http://www.w3.org/2000/svg" width="12"
                            height="12" viewBox="0 0 12 12" fill="none">
                            <path
                                d="M10.798 5.96301H9.95046C9.77494 5.96301 9.63264 6.10531 9.63264 6.28084V10.145C9.63264 10.3501 9.46572 10.517 9.26062 10.517H1.85503C1.64997 10.517 1.48318 10.3501 1.48318 10.145V2.73952C1.48318 2.53437 1.64997 2.36745 1.85503 2.36745H5.91703C6.09255 2.36745 6.23485 2.22515 6.23485 2.04963V1.2021C6.23485 1.02658 6.09255 0.884277 5.91703 0.884277H1.85503C0.832147 0.884277 0 1.71655 0 2.73952V10.145C0 11.168 0.832189 12.0002 1.85503 12.0002H9.26057C10.2835 12.0002 11.1158 11.1679 11.1158 10.145V6.28088C11.1158 6.10531 10.9735 5.96301 10.798 5.96301Z"
                                fill="#FFB224" />
                            <path
                                d="M11.6822 0H8.31101C8.13549 0 7.99319 0.1423 7.99319 0.317824V1.16535C7.99319 1.34088 8.13549 1.48318 8.31101 1.48318H9.46806L5.11409 5.83706C4.98997 5.96118 4.98997 6.16239 5.11409 6.28655L5.71337 6.88588C5.773 6.9455 5.85381 6.97898 5.93814 6.97898C6.02243 6.97898 6.10328 6.9455 6.16286 6.88588L10.5168 2.53191V3.68891C10.5168 3.86444 10.6591 4.00674 10.8347 4.00674H11.6822C11.8577 4.00674 12 3.86444 12 3.68891V0.317824C12 0.1423 11.8577 0 11.6822 0Z"
                                fill="#FFB224" />
                        </svg></a>
                    <a href="#" class="ps-4">FAQ’s <svg xmlns="http://www.w3.org/2000/svg" width="12"
                            height="12" viewBox="0 0 12 12" fill="none">
                            <path
                                d="M10.798 5.96301H9.95046C9.77494 5.96301 9.63264 6.10531 9.63264 6.28084V10.145C9.63264 10.3501 9.46572 10.517 9.26062 10.517H1.85503C1.64997 10.517 1.48318 10.3501 1.48318 10.145V2.73952C1.48318 2.53437 1.64997 2.36745 1.85503 2.36745H5.91703C6.09255 2.36745 6.23485 2.22515 6.23485 2.04963V1.2021C6.23485 1.02658 6.09255 0.884277 5.91703 0.884277H1.85503C0.832147 0.884277 0 1.71655 0 2.73952V10.145C0 11.168 0.832189 12.0002 1.85503 12.0002H9.26057C10.2835 12.0002 11.1158 11.1679 11.1158 10.145V6.28088C11.1158 6.10531 10.9735 5.96301 10.798 5.96301Z"
                                fill="#FFB224" />
                            <path
                                d="M11.6822 0H8.31101C8.13549 0 7.99319 0.1423 7.99319 0.317824V1.16535C7.99319 1.34088 8.13549 1.48318 8.31101 1.48318H9.46806L5.11409 5.83706C4.98997 5.96118 4.98997 6.16239 5.11409 6.28655L5.71337 6.88588C5.773 6.9455 5.85381 6.97898 5.93814 6.97898C6.02243 6.97898 6.10328 6.9455 6.16286 6.88588L10.5168 2.53191V3.68891C10.5168 3.86444 10.6591 4.00674 10.8347 4.00674H11.6822C11.8577 4.00674 12 3.86444 12 3.68891V0.317824C12 0.1423 11.8577 0 11.6822 0Z"
                                fill="#FFB224" />
                        </svg></a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
    function addTravelerModal() {
        var adults = $("#adult-count").text();
        var childs = $("#child-count").text();

        var adultList;
        var count = 1;
        for (var i = 1; i <= adults; i++) {
            if (i == 1) {
                adultList += `<span>
                            <input type="radio" id="list${count}" name="travelerTypes" value="Traveler ${count} - Adult" checked>
                            <label for="list${count}">Adult ${i}</label>
                        </span>`;
            } else {
                adultList += `<span>
                            <input type="radio" id="list${count}" name="travelerTypes" value="Traveler ${count} - Adult">
                            <label for="list${count}">Adult ${i}</label>
                        </span>`;
            }

            count++;
        }

        for (var j = 1; j <= childs; j++) {
            adultList += `<span>
                            <input type="radio" id="list${count}" name="travelerTypes" value="Traveler ${count} - Child">
                            <label for="list${count}">Child ${j}</label>
                        </span>`;
            count++
        }

        adultList = adultList.replace("undefined", "");

        $("#traveler-radio-list").html(adultList);


        $("#travelers").modal('show');
    }


    var travelersArray = [];

    function addTraveler() {
        var checkedValue = $('input[name="travelerTypes"]:checked').val();
        var travelerName = $("#traveler-name").val();
        var travelerDob = $("#traveler-dob").val();
        var travelerGender = $("#traveler-gender").val();

        var text = `<div class="d-flex justify-content-between border-bottom">
                        <div class="teveler-data">
                            <small>${checkedValue}</small>
                            <h6 class="fw-bold">${travelerName}</h6>
                        </div>
                        <a href="javascript:void(0)" onclick="editModel('${travelerName}','${travelerDob}','${travelerGender}')" class="blue  mt-3">Edit</a>
                      </div>`;

        $("#traveler-final-list").append(text);

        var existingTravelerIndex = -1;

        // Check if a traveler with the same checkedValue exists
        travelersArray.forEach(function(traveler, index) {
            if (traveler.checkedValue === checkedValue) {
                existingTravelerIndex = index;
            }
        });

        if (existingTravelerIndex !== -1) {
            // Update existing traveler data
            travelersArray[existingTravelerIndex] = {
                "checkedValue": checkedValue,
                "name": travelerName,
                "dob": travelerDob,
                "gender": travelerGender
            };
        } else {
            // Create a new traveler object
            var travelerData = {
                "checkedValue": checkedValue,
                "name": travelerName,
                "dob": travelerDob,
                "gender": travelerGender
            };
            // Add new traveler data to the array
            travelersArray.push(travelerData);
        }

        // Convert the array of traveler data into JSON
        var jsonTravelersData = JSON.stringify(travelersArray);
        console.log(jsonTravelersData);

        //   var id = $('input[name="travelerTypes"]:checked').next('label').text();

        $("#travelerListJson").val(jsonTravelersData);
        var travelerName = $("#traveler-name").val(' ');
        var travelerDob = $("#traveler-dob").val(' ');
        var travelerGender = $("#traveler-gender").val('Male');



    }

    function editModel(name, dob, gender) {

        $('#traveler-name-edit').val(name);
        $('#traveler-gender-edit').val(gender);
        $('#traveler-dob-edit').val(dob);

        $('#travelersEdit').modal('show');

    }
</script>

<?php echo $__env->make('layouts.userlayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\freelance\hotelTrip\resources\views/enquiry.blade.php ENDPATH**/ ?>