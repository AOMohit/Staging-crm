<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Fira+Sans:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Geologica:wght@100;300&family=Lato&family=Open+Sans&family=Poppins&family=Roboto&display=swap"
        rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
    <title>Document</title>
    <link href="<?php echo e(asset('public/userpanel')); ?>/asset/css/style.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.0/css/toastr.css" rel="stylesheet" />
</head>

<body>
    <header class="header-bg ">

    </header>

    <nav class="navbar sticky-top navbar-expand-lg navbar-light bg-white">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('dashboard')); ?>">
                <img src="<?php echo e(asset('public/userpanel')); ?>/asset/images/logo.png" alt="">
            </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight"
                aria-controls="offcanvasRight" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasRight"
                aria-labelledby="offcanvasRightLabel">
                <div class="offcanvas-header">

                    <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas"
                        aria-label="Close"></button>
                </div>

            </div>
            <div class="text-end d-none d-md-block">
                <a href="#" class="btn-btn-header">
                    <span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="19" viewBox="0 0 18 19"
                            fill="none">
                            <path
                                d="M9 0C8.01109 0 7.04439 0.293245 6.22215 0.842652C5.3999 1.39206 4.75904 2.17295 4.3806 3.08658C4.00216 4.00021 3.90315 5.00555 4.09607 5.97545C4.289 6.94536 4.7652 7.83627 5.46447 8.53553C6.16373 9.2348 7.05464 9.711 8.02455 9.90393C8.99445 10.0969 9.99979 9.99784 10.9134 9.6194C11.827 9.24096 12.6079 8.6001 13.1573 7.77785C13.7068 6.95561 14 5.98891 14 5C14 3.67392 13.4732 2.40215 12.5355 1.46447C11.5979 0.526784 10.3261 0 9 0ZM9 8C8.40666 8 7.82664 7.82405 7.33329 7.49441C6.83994 7.16476 6.45542 6.69623 6.22836 6.14805C6.0013 5.59987 5.94189 4.99667 6.05764 4.41473C6.1734 3.83279 6.45912 3.29824 6.87868 2.87868C7.29824 2.45912 7.83279 2.1734 8.41473 2.05764C8.99667 1.94189 9.59987 2.0013 10.1481 2.22836C10.6962 2.45542 11.1648 2.83994 11.4944 3.33329C11.8241 3.82664 12 4.40666 12 5C12 5.79565 11.6839 6.55871 11.1213 7.12132C10.5587 7.68393 9.79565 8 9 8ZM18 19V18C18 16.1435 17.2625 14.363 15.9497 13.0503C14.637 11.7375 12.8565 11 11 11H7C5.14348 11 3.36301 11.7375 2.05025 13.0503C0.737498 14.363 0 16.1435 0 18V19H2V18C2 16.6739 2.52678 15.4021 3.46447 14.4645C4.40215 13.5268 5.67392 13 7 13H11C12.3261 13 13.5979 13.5268 14.5355 14.4645C15.4732 15.4021 16 16.6739 16 18V19H18Z"
                                fill="black" />
                        </svg> &nbsp; WELCOME <span class="text-uppercase">
                            
                                <?php echo e($data->first_name); ?>

                                <?php echo e($data->last_name); ?>

                           
                        </span>
                    </span>
                </a>
            </div>
        </div>
    </nav>

    <div class="wrap mt-5 mb-5">
        <div class="container">
            <div class="col-12">
                <div class="row">
                    <div class="col-md-8 col-12 mx-auto d-block">
                        <h1 class="text-center">REGISTRATION FORM</h1>

                        <form action="<?php echo e(route('registration')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="email" value="<?php echo e($data->email); ?>">
                            <div class="row">
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Full Name*</label>
                                    <input type="text" name="name" required value="<?php echo e($data->first_name); ?>"
                                        placeholder="Full Name" class="form-control" id="">
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Phone Number*</label>
                                    <input type="text" name="phone" required value="<?php echo e($data->phone); ?>" placeholder=""
                                        class="form-control" id="">
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Choose Your Expedition</label>
                                    <select name="letest_trip" class="w-100 form-control" id="" required>
                                        <option value="">—Please choose an option—</option>
                                        <?php $__currentLoopData = $trip; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trips): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option
                                                <?php if(isset($data->letest_trip)): ?> value="<?php echo e($data->letest_trip); ?>" selected <?php else: ?> value="<?php echo e($trips->id); ?>" <?php endif; ?>>
                                                <?php echo e($trips->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">E-mail*</label>
                                    <input type="text" name="" value="<?php echo e($data->email); ?>" readonly
                                        placeholder="" class="form-control" id="">
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">State</label>
                                    <input type="text" name="state" value="<?php echo e($data->state); ?>" placeholder=""
                                        class="form-control" id="">
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Pincode</label>
                                    <input type="text" name="pincode" value="<?php echo e($data->pincode); ?>"
                                        placeholder="" class="form-control" id="">
                                </div>
                                <div class="col-md-12 col-12 my-2">
                                    <label for="">Address</label>
                                    <textarea name="address" id="" cols="10" rows="3" class="form-control"><?php echo e($data->address); ?></textarea>
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Date Of Birth *</label>
                                    <input type="text" name="dob" required
                                        value="<?php echo e($data->dob); ?>" class="form-control"
                                        id="">
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Profession *</label>
                                    <input type="text" name="profession" required value="<?php echo e($data->profession); ?>"
                                        class="form-control" id="">
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Blood Group *</label>
                                    <select name="blood_group" required class="w-100 form-control" id="" required>
                                        <option value="">—Please choose an option—</option>
                                        <option <?php if($data->blood_group == 'a+'): ?> selected <?php endif; ?> value="a+">A+
                                        </option>
                                        <option <?php if($data->blood_group == 'a-'): ?> selected <?php endif; ?> value="a-">A-
                                        </option>
                                        <option <?php if($data->blood_group == 'b+'): ?> selected <?php endif; ?> value="b+">B+
                                        </option>
                                        <option <?php if($data->blood_group == 'b-'): ?> selected <?php endif; ?> value="b-">B-
                                        </option>
                                        <option <?php if($data->blood_group == 'o+'): ?> selected <?php endif; ?> value="o+">O+
                                        </option>
                                        <option <?php if($data->blood_group == 'o-'): ?> selected <?php endif; ?> value="o-">O-
                                        </option>
                                        <option <?php if($data->blood_group == 'ab+'): ?> selected <?php endif; ?> value="ab+">AB+
                                        </option>
                                        <option <?php if($data->blood_group == 'ab-'): ?> selected <?php endif; ?> value="ab-">AB-
                                        </option>

                                    </select>
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Meal Preference *</label>
                                    <input type="text" required name="meal_preference"
                                        value="<?php echo e($data->meal_preference); ?>" placeholder="" class="form-control"
                                        id="">
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Choose T-Shirt Size *</label>
                                    <select name="t_size" required class="w-100 form-control" id="" required>
                                        <option value="">—Please choose an option—</option>
                                        <option <?php if($data->t_size == 'Kids'): ?> selected <?php endif; ?> value="Kids">Kids
                                        </option>
                                        <option <?php if($data->t_size == 'XS'): ?> selected <?php endif; ?> value="XS">XS
                                        </option>
                                        <option <?php if($data->t_size == 'S'): ?> selected <?php endif; ?> value="S">S
                                        </option>
                                        <option <?php if($data->t_size == 'M'): ?> selected <?php endif; ?> value="M">M
                                        </option>
                                        <option <?php if($data->t_size == 'L'): ?> selected <?php endif; ?> value="L">L
                                        </option>
                                        <option <?php if($data->t_size == '2XL'): ?> selected <?php endif; ?> value="2XL">2XL
                                        </option>
                                        <option <?php if($data->t_size == '3XL'): ?> selected <?php endif; ?> value="3XL">3XL
                                        </option>


                                    </select>
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Medical Condition if any *</label>
                                    <input type="text" required name="medical_condition"
                                        value="<?php echo e($data->medical_condition); ?>" placeholder="" class="form-control"
                                        id="">
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Emergency Contact Name *</label>
                                    <input type="text" required name="emg_name" value="<?php echo e($data->emg_name); ?>"
                                        placeholder="" class="form-control" id="">
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Emergency Contact Number </label>
                                    <input type="text" name="emg_contact" value="<?php echo e($data->emg_contact); ?>"
                                        placeholder="" class="form-control" id="">
                                </div>
                                <div class="col-md-12 col-12 my-2">
                                    <label for="">Tell us something about yourself in 20 words</label>
                                    <textarea name="something" id="" cols="10" rows="3" class="form-control"><?php echo e($data->something); ?></textarea>
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Have you done a road trip before? If yes, where? *</label>
                                    <input type="text" name="have_road_trip" required value="<?php echo e($data->have_road_trip); ?>"
                                        placeholder="" class="form-control" id="">
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Most Thrilling Experience of your life? *</label>
                                    <input type="text" name="thrilling_exp" required value="<?php echo e($data->thrilling_exp); ?>"
                                        placeholder="" class="form-control" id="">
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Three Travel essentials for Road Trips? *</label>
                                    <input type="text" name="three_travel" required value="<?php echo e($data->three_travel); ?>"
                                        placeholder="" class="form-control" id="">
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Three places in your bucket list? *</label>
                                    <input type="text" name="three_place" required value="<?php echo e($data->three_place); ?>"
                                        placeholder="" class="form-control" id="">
                                </div>

                                
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Passport Upload (Front)</label><br>
                                    <?php if(isset($data->passport_front)): ?>
                                        <img src="<?php echo e(asset('storage/app/'.$data->passport_front)); ?>" width="100px" alt="">
                                    <?php endif; ?>
                                    <input type="file" name="passport_front" placeholder="" class="form-control"
                                        id="">
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Passport Upload (Back)</label><br>
                                    <?php if(isset($data->passport_back)): ?>
                                        <img src="<?php echo e(asset('storage/app/'.$data->passport_back)); ?>" width="100px" alt="">
                                    <?php endif; ?>
                                    <input type="file" name="passport_back" placeholder="" class="form-control"
                                        id="">
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Pan Card / GST Certificate (For Billing Purpose)</label><br>
                                    <?php if(isset($data->pan_gst)): ?>
                                        <img src="<?php echo e(asset('storage/app/'.$data->pan_gst)); ?>" width="100px" alt="">
                                    <?php endif; ?>
                                    <input type="file" name="pan_gst" placeholder="" class="form-control"
                                        id="">
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Aadhaar Card Upload</label><br>
                                    <?php if(isset($data->adhar_card)): ?>
                                        <img src="<?php echo e(asset('storage/app/'.$data->adhar_card)); ?>" width="100px" alt="">
                                    <?php endif; ?>
                                    <input type="file" name="adhar_card" placeholder="" class="form-control"
                                        id="">
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Driving License Upload</label><br>
                                    <?php if(isset($data->driving)): ?>
                                        <img src="<?php echo e(asset('storage/app/'.$data->driving)); ?>" width="100px" alt="">
                                    <?php endif; ?>
                                    <input type="file" name="driving" placeholder="" class="form-control"
                                        id="">
                                </div>
                                <div class="col-md-6 col-12 my-2">
                                    <label for="">Profile Picture Upload (Candid) * ( Max Size:3mb
                                        )</label><br>
                                    <?php if(isset($data->profile)): ?>
                                        <img src="<?php echo e(asset('storage/app/'.$data->profile )); ?>" width="100px" alt="">
                                    <?php endif; ?>
                                    <input type="file" name="profile" required placeholder="" class="form-control"
                                        id="">
                                </div>
                                <div class="col-md-12 col-12 my-2">
                                    <label for="">Vaccination *</label>
                                    <select name="vaccination" class="w-100 form-control" id="" required>
                                        <option value="">—Please choose an option—</option>
                                        <option <?php if($data->vaccination == 'Singel'): ?> selected <?php endif; ?> value="Singel">Singel</option>
                                        <option <?php if($data->vaccination == 'Double'): ?> selected <?php endif; ?> value="Double">Double</option>
                                        <option <?php if($data->vaccination == 'None'): ?> selected <?php endif; ?> value="None">None</option>


                                    </select>
                                </div>
                                <div class="col-md-12 col-12 my-2">
                                    <label for="">Terms and Conditions*</label>
                                    <textarea name="" id="" required readonly cols="10" rows="10" class="form-control">
Important Information About These Terms

When you complete your Booking, you accept these Terms and Conditions (“Terms”) and any other terms and conditions that you are provided during the booking process. These Terms include an agreement to mandatory binding individual arbitration, which means that you agree to proceeding in court. If anything in these Terms is (or becomes) invalid or unenforceable, it will still be enforced to the fullest extent permitted by law and you will still be bound by everything else in these Terms. For all other terms and conditions, please refer to https://www.adventuresoverland.com/

1. Deposit/Payment Information

A deposit is required to confirm a reservation that shall be determined at the time of booking. For confirmed reservations, final payment in the form of a bank-wire, cheque, digital transfer or all major credit cards must be received on the date determined at the time of booking. If applicable, please contact your Travel Advisor for complete details. Failure to strictly comply with the deposit and final payment schedules, or any other applicable policies and procedures, will result in the automatic cancellation of pending reservations.

2. Guaranteed Departures

All Journeys are guaranteed to operate unless noted on the itinerary. Guaranteed departures will operate except only in cases of force majeure, which could include any major world event adversely affecting international travel patterns or other circumstances beyond AOPL’s control

3. AOPL Price Assurance

AOPL will not honour any lower advertised price on the Website for the same program, travel date and accommodation classification for all Group Journeys available through AOPL post booking of the Package. The Travel Advisor or Guest must contact AOPL for a price adjustment prior to travel. AOPL reserves the right to modify or cancel the AOPL Price Assurance for future bookings without prior notice.

4. Eligibility for Booking of Package/Tailor made Packages

4.1 Any person holding a valid passport and visa may register to participate in our international expeditions. For expeditions within India, we would require a valid photo id proof issued by Government of India or other Government for Foreign Customer. (E.g. Aadhaar Card, Election Card and Driving License).

4.2 The organizers at their discretion may accept or reject any registration and participant for the expedition. 

4.3 The package cost is for each participant and includes accommodation on single/double/triple occupancy basis along with breakfast, lunch and dinner or as per mentioned in the program. Most hotels allow check-in to take place during the mid- afternoon. Should you wish to have a guaranteed room ready for your immediate check-in upon arrival, it requires an additional room night to be confirmed. Please ask AOPL for details and prices. Requests for early check-in based on hotel availability cannot be guaranteed and are at the sole discretion of the hotel.

4.4 Upgrades are typically available on request at individual hotels for an additional cost. Please ask AOPL for details and prices. Specific requests such as adjacent or connecting rooms, bedding requests, smoking rooms and special dietary needs should be advised at time of booking. Please note that reasonable efforts will be made to secure special requests; however, they cannot be guaranteed.

4.5 The suppliers of some activities on Journeys may require a minimum age or minimum/maximum height or weight to participate. Some active elements have been incorporated into select itineraries. To enjoy the Journeys as intended, a minimum level of fitness is required.

By booking a Journey, Guest represents that Guest and Guest’s travelling party are physically and emotionally fit to travel and further warrants that such Guests have no medical or emotional condition that would endanger any Guest or result in a deviation of the Journey. Any Guest with special medical, physical, or other needs requiring medical attention or special accommodation during the Journey is requested to notify AOPL in writing at the time of the booking of such special needs. Upon booking the Journey, Guests who have special needs are requested to contact AOPL to discuss details of their special needs. AOPL recommends that any Guest who is not self- sufficient should travel with a companion who shall take responsibility for any personal assistance needed during the Journey.

For Journeys, due to Certain restrictions, women who will be at least seven (7) months pregnant at the start of the Journey, or any time during the expedition, will not be permitted to travel.

4.6 In case of any medical assistance is required by a participant, the accompanying team will try and provide the necessary assistance within their means and the medical supplies and equipment available with them. The organizers may decide to transport the participant to the nearest appropriate medical facility. Decisions will be based only on the medical aspect and the respect of the health regulations in vigour, either to hospitalize the participant in a nearby medical facility, before envisaging transport to the nearest hospital/facility at the nearest town. It is, in this regard, expressly stated that the final decision concerning the medical interest of the participant, remains with the attending doctor. In the case where participant refuses to follow the decision considered as the most opportune by the attending doctor, they discharge the organizers of all responsibility, notably in the case where the participant returns by their means or in the case where the participant aggravates their health. They may therefore not make any claim of expenses incurred to be refunded in the conditions mentioned above. The attending doctor to take the final decision to transfer or repatriate him/her. In such an event, any extra cost occurred will be borne by the participant.

4.7 Incase of a breakdown, the accompanying team will try to carry out with possible help available with them. In case of a major breakdown that cannot be repaired, the organizers will use their best effort to arrange for repair service at the nearest point or arrange a replacement vehicle.

4.8 The organizers shall not be responsible for delays or alterations in the plan or expenses incurred – directly or indirectly due to natural hazards, accident, mechanical breakdowns, weather, sickness, landslides etc. 

4.9 Force majeure means unusual and unforeseeable circumstances beyond AOPL’s, control or the control of our suppliers, the consequence of which neither AOPL’s, nor its suppliers, could avoid even with all due care, including, but not limited to, war or threat of war; riot; civil strife; terrorist activity (actual or threatened); industrial dispute; technical problems with transport, machinery or equipment; outages or power failures; natural or nuclear disaster; fire, flood, drought or adverse weather conditions; pandemics, epidemics or outbreaks of illness; and ice conditions in oceans and level of water in rivers. In the event of a cancellation or material alteration to the Journey as a result of the circumstances as described in this clause, AOPL shall have no liability whatsoever for any travel related costs incurred by Guest, including but not limited to arrangements of any kind. In case the journey has to be discontinued due to any reason(s), no request to refund the charges for the remaining journey will be entertained due to prior bookings and commitments made ahead of the trip.

5. Limitation of LiabilityThese Terms and Conditions govern the relationship between you, the participant and Adventures Overland Pvt. Ltd. By joining the expedition, you are bound by these Terms and Conditions. Although Adventures Overland Pvt. Ltd. is making the arrangement for this expedition, our responsibility is limited. The limits of our commitment arise from the fact that we liaise with independent third parties such as hotel, transportation companies and other ground operators. By accepting and utilizing the goods or services of third parties, each participant agrees that Adventures Overland Pvt. Ltd shall not be held liable in any way for any loss, injury, damage, delay or death or property loss or damage arising from any act or omission of any such third party. Adventures Overland in benefit of all reserves the right to make changes in the itinerary at its sole discretion.

6. Photography During Travel

AOPL reserves the right to take photographs and video of Guests during the operation of any Journey or part thereof and to use, re-use, publish, and republish their image, identity likeness, voice, interview, statements, video clips and sound recordings, and/or photographic portraits or pictures in which Guest(s) may be included (an “Image”), for promotional purposes during the program and thereafter. By booking a Journey with AOPL, Guests acknowledge that AOPL is the owner of the photographs and video and agree to allow their Image to be used in such photographs and videos, which may thereafter be used by AOPL.

7. You will have to contend with lifestyles and cultures that are very different from your own. You must come prepared to cope with unpredictable situations, local inadequacies and unforeseeable events. Even with our detailed organization, things can go wrong. Many places where we travel are off the beaten track, maybe economically and politically unstable. Adventures Overland Pvt. Ltd will not be responsible for any delays caused due to unavoidable circumstances in the regions through which we will bedriving.

8. Limits On Aopl’s Responsibility For Third Parties Who Provide Goods And Services 

AOPL purchases hotel and other lodging accommodations, restaurant, ground handling and other services from various independent suppliers (including, from time to time, other affiliates of AOPL). Neither AOPL nor its parent company, affiliates or subsidiaries, nor any of their respective employees, shareholders, officers, directors, successors, representatives, agents and assigns (collectively the “AOPL Parties”), own or operate any transportation, lodging accommodations on land, restaurants, ground transport and other goods and services for your trip. All such persons and entities are independent contractors. As a result, the AOPL Parties are not liable for any injury to Guest, including any negligent or wilful acts of any such person or entity or of any third person providing such goods and services.

In addition and without limitation, the AOPL Parties are not responsible for any injury, financial or physical loss, death, inconvenience, delay or damage to personal property in connection with the provision of any goods or services whether resulting from but not limited to acts of God or force majeure, illness, disease, acts of war, civil unrest, insurrection or revolt, animals, strikes or other labor activities, criminal or terrorist activities of any kind, overbooking or downgrading of services, food poisoning, mechanical or other failure of aircraft or other means of transportation or for failure of any transportation mechanism to arrive or depart on time.

There are many inherent risks in adventure travel of the type involved here, which can lead to illness, injury, or even death. These risks are increased by the fact that these trips take place in remote locations, far from medical facilities. Guest assumes all such risks associated with participating in the Journeys.

If you decide to participate in any activities including, but not limited to, any excursions involving animals, riding on animals, scuba diving, snorkeling, boating, hot air ballooning, helicopter flights, ziplining, high altitude treks, climbing, quad biking, parasailing, parachuting, kayaking, whitewater rafting, jet boat rides, snowmobiling, primate tracking and any other activity which AOPL considers to carry inherent risk of serious illness, injury or death (“Activities”), then you fully understand and acknowledge that Activities carry with them various inherent risks, including serious illness, injury or death, and you take complete responsibility for your own health and safety and agree to assume all risks of injury, illness or death, whether foreseen or unforeseen, that may befall you as a result of participating in any Activities and agree to release the AOPL Parties from any liability whatsoever related there to.

Further, as consideration for being permitted to participate in the Activities; you release the AOPL Parties, whether known or unknown, from, and agree not to sue or make claim against the AOPL Parties for, property damage, cancellation of any Activities for any reason, illness, negligent rescue operations or procedures, personal injury, or death arising out of your participation in the Activities, and any activity related thereto, including transportation to and from the site of the Activities, regardless of whether such property damage, illness, personal injury, or death results from the negligence of the AOPL Parties and/or from any defect in equipment. You further agree to indemnify and hold the AOPL Parties harmless with respect to any claim made against the AOPL Parties by anyone else (a) related to your participation in any trip or any Activities, or (b) which would be subject to the above release and covenant not to sue if you had made the claim directly yourself. Upon receipt of notice of the assertion of a claim, the AOPL Parties reserve the right to approve, or withdraw approval of, counsel, in its sole discretion.

9. Travel during COVID-19

All participants must follow certain protocols and safety measures on the expedition such as wearing masks, regular use of hand sanitisers, social distancing etc. Every participant is required to submit a COVID-19 RT-PCR negative test report which should not be more than 72 hours old before the first day of the trip. During the journey, if a participant shows any symptoms of COVID-19 infection, he/she must immediately inform the Expedition Leaders. Each participant is joining the expedition at their own risk and Adventures Overland shall not be held responsible in case a participant is found to be infected with COVID-19 during the expedition.

10. The enjoyment and excitement of adventure travel are derived in part from the inherent risks incurred by driving through the less well-developed regions listed on the itineraries and undertaking activities beyond the levels of safety normal at home or work. Therefore, our expeditions are not suitable for people who expect to be indulged or demand for everything to go exactly as planned. For your own interest, and that of your fellow participants, please do not book an expedition if the above is not acceptable to you.

11. Indemnity, Waiver And Declaration 

I hereby make an application to participate in the following expedition organized by Adventures Overland Pvt. Ltd. and certify that all particulars including of my vehicle as given in the entry form are correct.

For the purposes hereof, Adventures Overland Pvt. Ltd, along with its shareholders, sponsors, affiliates, sub-contractors and suppliers and all of their respective officers, directors, employees, servants and agents are hereinafter collectively referred to as the “Organizers”.

I hereby confirm that I have read, understood and agree to all rules and regulations, terms and conditions relating to or affecting my participation in this expedition including but not limited to the Supplementary Regulations issued by the Organizers for the same. I agree to abide by all relevant rule and regulations affecting the expedition as the same may change from time to time.

I hereby confirm that I am fully conversant with the risks associated with long distance expeditions in general and this expedition specifically. I accept that this event is potentially dangerous and involve risky activities – presented as a challenge. I understand that participation in this expedition specifically can lead to injury or death and I knowingly and willingly accept these risks completely.

To avoid the time and expense of protracted litigation and to allow the Organizers and myself to arrange for insurance or self-insurance as deemed appropriate to address the relevant risks, the responsibility for certain claims shall be allocated in accordance herewith. Regardless of Cause, I Shall Be Liable for And Indemnify Organizers from and against any and all claims, arising out of personal injury, illness, death, or property loss or damage suffered by me.

For the purposes here of:

“Claim(s)” shall mean all claims, damages (excluding punitive or exemplary damages), liabilities, losses, demands, liens, encumbrances, causes of action of any kind, obligations, costs, judgments, interest, and awards (including, without limitation, legal counsel fees and costs of litigation if awarded as part of the judgment in favour of the person asserting the Claim), whether created by law, contract, tort, voluntary settlement, or otherwise, arising out of, related to, or in any way connected with this expedition.

“Gross Negligence” means such an entire lack of care as to indicate a conscious indifference and reckless disregard for the safety of people and property and includes wilful misconduct.

“Negligence” means any sole or concurrent negligent act or omission, fault (including, without limitation, pre-existing conditions), strict liability, breach of duty or warranty (statutory or otherwise), product liability, defect (whether patent, latent, or pre-existing) of any property, equipment, or materials and shall include passive as well as active Negligence.

“Regardless of Cause” means without regard to Negligence, in whole or in part, of the party seeking indemnity or of any other person. Where expressly stated, Regardless of Cause also means without regard to Gross.

Negligence, in whole or in part, of the person seeking indemnity or of any other person.

“Shall Be Liable for And Indemnify” means the indemnifying party shall be solely responsible for and assume all liability for and defend, release and indemnify and hold harmless the indemnified party or other per “Third Party” means any person other than the Organizers or myself. This indemnity shall be binding on my heirs, executors and legal representatives.

I hereby confirm that I have obtained all necessary insurances relating to myself for this expedition.

I declare that I possess the standard of competence necessary for an event of this type to which this entry relates.

I hereby confirm that the Organizers shall have no liability towards me and hereby forever discharge the Organizers of and from all actions, causes of action, suits, debts, obligations, claims and demands whatsoever which I have or hereafter can, shall, or may have.

I accept that though reasonable efforts will be made for ensuring my safety on this expedition, it may not be possible for the Organizers to undertake the following:

1. To evacuate me by air ambulance due to any reason whatsoever,

2. To ensure that the evacuation to nearest medical care facility, in case of an accident will be undertaken with a lifesaving ambulance. The Organizers may undertake evacuation by the means that they deem appropriate under the circumstances,

3. To provide advanced surgery and health care facilities on the route itself, and evacuation to the nearest medical facility might take any number of hours, 4. To guarantee that no oncoming traffic may be the cause of injuries to my person,

I understand that the consumption of alcohol, narcotic, psychotropic and other similar substances are not permitted on the expedition and I agree to be excluded from the event if found, during the actual running of the event, to have consumed any of the above.

I hereby indemnify the Organizers against any defects on route or any decisions, under pressure of time/ events, made by them during the expedition. I acknowledge and agree that if required, the Organizers may arrange such medical or hospital treatment (including ambulance transportation) for me as they find appropriate in the circumstances. I authorize and ratify such actions being taken by them and agree to meet all costs and expenses associated with such actions. I understand and accept that it is compulsory for me to have comprehensive medical insurance and I accept responsibility for the cost of medical expenses that may exceed the cover provided by my insurance.

12. Statutory Safeguards And Optimal Liability Protections For Aopl

Nothing in these Terms shall limit or deprive AOPL of the benefit of any applicable statutes or laws of the India or any other country; or any international convention providing for release from, or limitation of, liability. In the event multiple statutes, laws or conventions may apply, AOPL shall be entitled to any or all such limitations unless there is a conflict between such statutes, laws or conventions, in which case AOPL shall be entitled to invoke the limitation which provides the most favourable limitation to AOPL.

I confirm that I have obtained legal advice prior to signing this document.
                                   </textarea>
                                </div>
                                <div class="col-md-12 col-12 my-2">

                                    <input type="checkbox" name="" id=""> Yes, I have read and agree
                                    to the Terms of Service.
                                </div>

                            </div>
                            <button class="btn btn-secondary rounded-pill p-2 px-5 mt-2">Register</button>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\freelance\ao-new\resources\views/registration.blade.php ENDPATH**/ ?>