
<?php $__env->startSection('container'); ?>
    <div class="col-md-10 col-12">
        <div class="border-shadow">
            <div class="card">
                <div class="card-header bg-white information">

                    <?php echo $__env->make('layouts.userlayout.card-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                </div>
                <div class="card-body">
                    <h6 class="text fw-bold mb-3">How to Climb a Tier</h6>
                    <div class="col-12">
                        <div class="row">
                            <div class="col-md-3 col-12 overview-img">
                                <img src="<?php echo e(asset('public/userpanel')); ?>/asset/images/overview-page.png" alt="">
                            </div>
                            <div class="col-md-9 col-12 px-3">
                                <?php echo setting('discovery'); ?>

                            </div>
                        </div>
                    </div>

                    <div class="col-12 mt-3">
                        <div class="row">
                            <div class="col-md-3 col-12 overview-img">
                                <img src="<?php echo e(asset('public/userpanel')); ?>/asset/images/explore.png" alt="">
                            </div>
                            <div class="col-md-9 col-12 px-3">
                                <?php echo setting('explorer'); ?>


                            </div>
                        </div>
                    </div>

                    <div class="col-12 mt-3">
                        <div class="row">
                            <div class="col-md-3 col-12 overview-img">
                                <img src="<?php echo e(asset('public/userpanel')); ?>/asset/images/legends.png" alt="">
                            </div>
                            <div class="col-md-9 col-12 px-3">
                                <?php echo setting('legends'); ?>


                            </div>
                        </div>
                    </div>

                    <div class="col-12 mt-3">
                        <div class="row">
                            <div class="col-md-3 col-12 overview-img">
                                <img src="<?php echo e(asset('public/userpanel')); ?>/asset/images/Discovery.png" alt="">
                            </div>
                            <div class="col-md-9 col-12 px-3">
                                <?php echo setting('adventurer'); ?>


                            </div>
                        </div>
                    </div>

                    <?php echo $__env->make('imp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.userlayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\freelance\ao-new\resources\views/climb-tier.blade.php ENDPATH**/ ?>