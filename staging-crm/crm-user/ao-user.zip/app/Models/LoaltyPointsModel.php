<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LoaltyPointsModel extends Model
{
    protected $table = 'loyality_pts';
    use HasFactory;
}
