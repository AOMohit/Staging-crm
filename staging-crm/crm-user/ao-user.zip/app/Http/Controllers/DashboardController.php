<?php

namespace App\Http\Controllers;

use App\Models\EnqueiryModel;
use App\Models\TransferModel;
use App\Models\Countrie;
use App\Models\State;
use App\Models\Trip;
use App\Models\ExtraDocuments;
use App\Models\User;
use App\Models\LoaltyPointsModel;
use App\Models\Mytrips;
use App\Models\TripBooking;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Admin\MailContorller;

class DashboardController extends Controller
{
    //
    function home(){
        $user = User::where('id',Auth::user()->id)->first();

        return view('dashboard',['user'=>$user]);
    }

    function myTrip(){
        $cos_id = Auth::user()->id;
        $trip = TripBooking::whereJsonContains('customer_id', "$cos_id")->where('trip_status','!=','Draft')->orderBy('id','desc')->get();
        // dd($trip);
        return view('my-trip',['trip'=>$trip]);
    }

    function tripDetails(Request $request){
        $data = TripBooking::where('token',$request->token)->first();
        return view('trip-details',compact('data'));
    }

   function myPoint()
    {
        $redeem = LoaltyPointsModel::where(['customer_id'=>Auth::user()->id, 'trans_type'=>'Dr'])->sum('trans_amt');
        $point = LoaltyPointsModel::where('customer_id',Auth::user()->id)->orderBy('id','desc')->get();
        return view('my-point',['point'=> $point, 'redeem'=> $redeem]);
    }
    function climbTier(){
        return view('climb-tier');
    }

    function howToEarn()
    {
        return view('how-earn');
    }

    function redeemPoint()
    {
        // $trip = Trip::where('trip_type','Fixed Departure')->orderBy('id', 'desc')->get();
        $trip = Trip::orderBy('name', 'asc')->where('trip_type','Fixed Departure')->where('status', '!=', 'Cancelled')->whereDate('end_date', '>=', date("Y-m-d"))->get();
        return view('remeed-point',['trip'=>$trip]);
    }
    function transferPoint()
    {
        $transfer = TransferModel::where('customer_id',Auth::user()->id)->sum('trans_amt');
        $reciver = TransferModel::where('reciever_mail',Auth::user()->email)->sum('trans_amt');
        // $reciver = 
        $data = TransferModel::where(['customer_id'=>Auth::user()->id])->orwhere(['reciever_mail'=>Auth::user()->email])->orderBy('id','desc')->get();
        // dd($data);
        return view('transfer-point',['transfer'=>$transfer,'reciver'=>$reciver,'data'=>$data]);
    }

    function registration(){
        if(isset($_GET['email']) && $_GET['email'] != Null){
            $data = User::where('email', $_GET['email'])->first();
            if(isset($data) && $data != Null){
                $trip = Trip::orderBy('id', 'desc')->get();
               $extra = ExtraDocuments::where('user_id', $data->id)->get();
                return view('registration', ['trip' => $trip, 'data' => $data,'extra'=>$extra]);
            }
            else{
                return redirect()->route('login');
            }
            
        }
        else{
            return redirect()->route('login');
        }
        
    }

    function email(){
        return view('email');
    }

    function transferCoin(Request $request){
        $today = today();
        $date = date('Y-m-d', strtotime($today . " +1 year"));
        // dd($date);
        $reciver_user = User::where('email',$request->email)->first();
        if(isset($reciver_user)){
            if(Auth::user()->points >= $request->points){
                $trans = new TransferModel();

                $total = $reciver_user->points + $request->points;
                $reciver_user->points = $total;
                
                $reciver_user->save();

                $trans->customer_id = Auth::user()->id;
                $trans->reciever_mail = $request->email;
                $trans->trans_type = 'Credit';
                $trans->trans_amt = $request->points;
                $trans->balance = $total;
                $trans->expiry_date = $date;
                // dd($trans);
                $trans->save();

                $sender_user = User::where('id',Auth::user()->id)->first();
                $stotal = $sender_user->points - $request->points;
                $sender_user->points = $stotal;

                $strans = new TransferModel();

                $strans->customer_id = Auth::user()->id;
                $strans->reciever_mail = $request->email;
                $strans->trans_type = 'Debit';
                $strans->trans_amt = $request->points;
                $strans->balance = $stotal;
                $strans->save();
               
                $sender_user->save();
                
                $mail = new MailContorller();
                $type = 'trans-sender-mail';
                $mail->index2($strans, $type);

                $mail = new MailContorller();
                $type = 'trans-reciver-mail';
                $mail->index2($strans, $type);

                return redirect()->back()->with('message', 'Points Send Successfully.');


            }
            else{
                return redirect()->back()->with('error', 'Insufficient Points.');

            }
        }
        else{
            return redirect()->back()->with('error', 'This Email Dose Not Exist');

        }
    }

    function password()
    {
        return view('change-password');
    }

    function enquiry()
    {
        $trip = Trip::orderBy('name', 'asc')->where('trip_type','Fixed Departure')->where('status', '!=', 'Cancelled')->whereDate('end_date', '>=', date("Y-m-d"))->get();
        // dd($trip);
        
        return view('enquiry', ['trip' => $trip]);
    }

    function enquirySubmit(Request $request)
    {
        // dd($request->travelerListJson);
        if($request->type == 'enquiry'){
            if(!isset($request->travelerListJson) && $request->travelerListJson == NULL){
                return redirect()->back()->with('error', 'Please Add Treveler');
            }
           
        }
        
        $enquiry = new EnqueiryModel();
        $enquiry->traveler = $request->travelerListJson;
        $enquiry->expedition = $request->expedition;
        $enquiry->minor = $request->minor;
        $enquiry->adult = $request->adult;
        $enquiry->redeem_points_status = $request->redeem_points_status;
        if($request->redeem_points_status == 'yes'){
            // dd(Auth::user()->points);
            $enquiry->redeem_points = Auth::user()->points;
        }
        $enquiry->customer_id = Auth::user()->id;
        if(Auth::user()->points >= $request->redeem_points){

            $enquiry->redeem_points =$request->redeem_points;
        }else{
            return redirect()->back()->with('error', 'You Have Not Sufficient Coins');

        }
        
        
        $enquiry->save();
        // dd($enquiry);
        if (isset($request->type) && $request->type == 'redeem') {
            
            $mail = new MailContorller();
            $type = 'redeem';
            $mail->index2($enquiry,$type);
        }
        else{
            $mail = new MailContorller();
            $type = 'enquiry';
            $mail->index2($enquiry, $type);
        }
        

        return redirect()->back()->with('message','We have recieved your request for redeeming points. Someone will get back to you shortly.');
    }



    function profile()
    {
        return view('profile-page');
    }
    
    function getState(Request $request){
        $value = Countrie::where('name',$request->value)->first();
        // dd($value);
        $data = State::where('country_id', $value->id)->orderBY('name','asc')->get();
        // dd($data);

        $html="";
       
        foreach ($data as $allstate) {
            //    dd($select_cat);
            $html .= '<option value="'. $allstate->name .'">' . $allstate->name . '</option>';
        }
        // dd($html);
       
        echo $html;
    }

    function profileUpdate(Request $request)
    { 
        // dd($request);
        // $request->validate([
        //     'first_name'=>'required',
        //     'phone'=>'required',
            
        // ]);

        $user = User::find(Auth::user()->id);
        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->phone = $request->phone;
        $user->dob = $request->dob;
        $user->city = $request->city;
        $user->state = $request->state;
        $user->country = $request->country;
        $user->pincode = $request->pincode;
        $user->pincode = $request->pincode;
        $user->address = $request->address;
        $user->meal_preference = $request->meal_preference;
        $user->profession = $request->profession;
        $user->blood_group = $request->blood_group;
        $user->emg_contact = $request->emg_contact;
        $user->t_size = $request->t_size;
        $user->medical_condition = $request->medical_condition;
         $user->something = $request->something;
        $user->have_road_trip = $request->have_road_trip;
        $user->thrilling_exp = $request->thrilling_exp;
        $user->three_travel = $request->three_travel;
        $user->three_place = $request->three_place;
        $user->letest_trip = $request->letest_trip;
        $user->vaccination = $request->vaccination;
        // dd($user);
        if ($request->hasFile('profile')) {
            // dd('hiii');
            @unlink('storage/app/' . $user->profile);
            $user->profile = $request->file('profile')->store('public/image/user');
        }
        // dd($user);
        $user->save();
        return redirect()->back();
    }

    function getPrice(Request $request){
        $trip = Trip::where('id',$request->value)->first();
        // dd()
        $price = $trip->price;

        return $price;

    }

    function registrationSubmit(Request $request)
    {
        
        $user = User::where('email', $request->email)->first();
       
        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->phone = $request->phone;
        $user->dob = $request->dob;
        $user->city = $request->city;
        $user->state = $request->state;
        $user->country = $request->country;
        $user->pincode = $request->pincode; 
        $user->address = $request->address;
        $user->meal_preference = $request->meal_preference;
        $user->profession = $request->profession;
        $user->blood_group = $request->blood_group;
        $user->emg_contact = $request->emg_contact;
        $user->emg_name = $request->emg_name;
        $user->t_size = $request->t_size;
        $user->medical_condition = $request->medical_condition;
        $user->something = $request->something;
        $user->have_road_trip = $request->have_road_trip;
        $user->thrilling_exp = $request->thrilling_exp;
        $user->three_travel = $request->three_travel;
        $user->three_place = $request->three_place;
        $user->letest_trip = $request->letest_trip;
        $user->vaccination = $request->vaccination;
        // dd($user);
        if ($request->hasFile('profile')) {
            // dd('hiii');
            @unlink('storage/app/' . $user->profile);
            $user->profile = $request->file('profile')->store('public/image/user');
        }
        if ($request->hasFile('passport_front')) {
            // dd('hiii');
            @unlink('storage/app/' . $user->passport_front);
            $user->passport_front = $request->file('passport_front')->store('public/image/user');
        }
        if ($request->hasFile('passport_back')) {
            // dd('hiii');
            @unlink('storage/app/' . $user->passport_back);
            $user->passport_back = $request->file('passport_back')->store('public/image/user');
        }
        if ($request->hasFile('pan_gst')) {
            // dd('hiii');
            @unlink('storage/app/' . $user->pan_gst);
            $user->pan_gst = $request->file('pan_gst')->store('public/image/user');
        }
        if ($request->hasFile('adhar_card')) {
            // dd('hiii');
            @unlink('storage/app/' . $user->adhar_card);
            $user->adhar_card = $request->file('adhar_card')->store('public/image/user');
        }
        if ($request->hasFile('driving')) {
            // dd('hiii');
            @unlink('storage/app/' . $user->driving);
            $user->driving = $request->file('driving')->store('public/image/user');
        }
        // dd($user);
        $user->save();
        foreach($request->title as $key=>$title){
            if(isset($title) && $title != NULL){
                if(isset($request->id[$key]) && $request->id[$key] != NULL){
                        $doc = ExtraDocuments::where('id',$request->id[$key])->first();
                        // $doc = $extra;
                }else{

                    $doc = new ExtraDocuments();
                }
                    
                    $doc->title = $title;
                    if (isset($request->file('image')[$key]) && $request->file('image')[$key] != NULL) {
                        info($request->title);
                        @unlink('storage/app/' . $doc->image[$key]);
                        $doc->image = $request->file('image')[$key]->store('public/image/user/extra');
                    }
                    $doc->user_id = $user->id;
                    $doc->save();

            }
        }
            $mail = new MailContorller();
        $type = 'registartion-user-mail';
        $mail->index2($user, $type);
        //mail to admin 
        $admin1 = Admin::select('users.email', 'users.name')->join('roles', 'roles.id', '=', 'users.role_id')->join('permissions', 'roles.permission_id', '=', 'permissions.id')->where('permissions.admin', 1)->get();
        $admin2 = Admin::select('users.email', 'users.name')->where('users.is_main_admin', 1)->get();
        $admins = new Collection();
        foreach ($admin1 as $item) {
            $admins->push($item);
        }

        foreach ($admin2 as $item) {
            $admins->push($item);
        }
        
        foreach ($admins as $admin) {
            $data = [
                'user_mail'=>$user->email,
                'admin_email' => $admin->email,
                'trip' => $trip->name,
            ];
            
            $mail = new MailContorller();
            $type = 'registartion-mail';
            $mail->index2($data, $type);
        }
        
        return redirect()->back();
    }
    
    function removeImage(Request $request){
        $data = ExtraDocuments::find($request->id);



        @unlink('storage/image/'.$data->image);
        $data->delete($request->id);

        echo 1;
    }

    public function summary(Request $request){
        $token = $request->token;

        $data = TripBooking::where('token', $token)->first();

        $result = [];

        if($data){
            // trip cost
            if($data->trip_cost != null){
                $tripCost = json_decode($data->trip_cost);
                foreach($tripCost as $tc){
                    $tc->traveler = getCustomerById($tc->c_id)->name;
                    $tc->parent = getCustomerById($tc->c_id)->parent;
                    $tc->vehicle_amt = $data->vehical_seat_amt ?? 0;
                    $tc->room_amt = $data->room_type_amt ?? 0;
                }
            }else{
                $tripCost = [];
            }
            $result['trip_costs'] = $tripCost;
            // trip cost

            // extra services
            if($data->trip_cost != null && $data->extra_services != null){
                $extraServices = json_decode($data->extra_services);
                foreach($extraServices as $es){
                    $es->traveler_name = getCustomerById($es->traveler)->name;
                    $es->extra_charges = $es->amount + $es->markup + (($es->markup*$es->tax)/100);
                }
            }else{
                $extraServices = [];
            }
            $result['extra_services'] = $extraServices;
            // extra services
            //vehicle sec amount
            $result['vehicle_security'] = ['amount'=>$data->vehical_security_amt, 'comment'=>$data->vehical_security_amt_cmt];
            $result['vehicle_seat_charge'] = $data->vehical_seat_amt;
            $result['vehicle_seat'] = $data->vehical_seat;

            //room info
            $result['room_info'] = json_decode($data->room_info) ?? [""]; 

            // sum of package B
            $packageBSum = 0;
            if(count($result['room_info'])){
                foreach($result['room_info'] as $packB){
                    if($packB->room_type_amt){
                        $packageBSum += $packB->room_type_amt;
                    }
                }
            }
            $packageBSum += $data->vehical_seat_amt;
            if(count($tripCost) > 0){
                $travellerCount = count($tripCost);
            }else{
                $travellerCount = 1;
            }
            $perTravellerPackageB = $packageBSum/$travellerCount;
            // Package B

            
            // tax
            if($data->trip_id && $data->customer_id && $data->trip_cost && ($data->tax_required == null || $data->tax_required == 0)){
                $gst = setting('gst') ?? 0;
                $tcs = setting('tcs') ?? 0;

                $tripTax = json_decode($data->trip_cost);
                $gsts = [];
                foreach($tripTax as $tt){
                    $netCost = $tt->cost;
                    $traveler = getCustomerById($tt->c_id)->name;
                    $gst_amt = (($netCost*$gst)/100);
                    $gst_per = $gst;
                    array_push($gsts, ['c_id'=>$tt->c_id,'traveler'=>$traveler, 'gst'=>$gst_amt, 'gst_per'=>$gst_per]);
                }

                $tcss = [];
                foreach($tripTax as $tt){
                    $netCost = $tt->cost;
                    $traveler = getCustomerById($tt->c_id)->name;
                    if($data->payment_from == "Individual" && $data->payment_from_tax != null){
                        $tcs_amt = (($netCost*$data->payment_from_tax)/100);
                        $tcs_per = $data->payment_from_tax;
                    }elseif($data->payment_from == "Company"){
                        $tcs_amt = (($netCost*$tcs)/100);
                        $tcs_per = $tcs;
                    }
                    array_push($tcss, ['c_id'=>$tt->c_id, 'traveler'=>$traveler, 'tcs'=>$tcs_amt, 'tcs_per'=>$tcs_per]);
                }
                $tripTax = ['gst'=>$gsts, 'tcs'=>$tcss];
            }else{
                $tripTax = [];
            }
            $result['taxes'] = $tripTax;
            // tax

            // redeemable points
            if($data->redeem_points){
                $rps = json_decode($data->redeem_points);
                if($rps){
                    foreach($rps as $rp){
                        $rp->traveler = getCustomerById($rp->c_id)->name;
                    }
                    $result['points'] = $rps;
                }
            }else{
                $result['points'] = 0;
            }
            // redeemable points

            // package offered A
            if($data->trip_cost != null){
                $packageOfferA = json_decode($data->trip_cost);
                $rps = json_decode($data->redeem_points);
                foreach($packageOfferA as $tc){
                    $tc->traveler = getCustomerById($tc->c_id)->name;
                    if($rps){
                        foreach($rps as $rp){
                            if($rp->c_id == $tc->c_id){
                                $tc->cost = $tc->cost - $rp->points;
                            }
                        }
                    }
                }
            }else{
                $packageOfferA = [];
            }
            $result['package_offer_A'] = $packageOfferA;
            // package offered A

            // A + B
            if($data->trip_cost != null){
                $A_B = json_decode($data->trip_cost);
                $rps = json_decode($data->redeem_points);
                foreach($A_B as $tc){
                    $tc->traveler = getCustomerById($tc->c_id)->name;
                    $tc->cost = $tc->cost + $perTravellerPackageB;
                    if($rps){
                        foreach($rps as $rp){
                            if($rp->c_id == $tc->c_id){
                                $tc->cost = $tc->cost - $rp->points;
                            }
                        }
                    }
                }
            }else{
                $A_B = [];
            }
            $result['a_and_b'] = $A_B;
            // A + B

            // C
            if($data->trip_cost != null){
                $packageC = json_decode($data->trip_cost);
                $rps = json_decode($data->redeem_points);
                foreach($packageC as $tc){
                    $tc->traveler = getCustomerById($tc->c_id)->name;
                    $tc->cost = $tc->cost + $perTravellerPackageB;
                    if($rps){
                        foreach($rps as $rp){
                            if($rp->c_id == $tc->c_id){
                                $tc->cost = $tc->cost - $rp->points;
                            }
                        }
                    }
                    foreach($tripTax['gst'] as $gst){
                        if($gst['c_id'] == $tc->c_id){
                            $tc->cost = $tc->cost + $gst['gst'];
                        }
                    }
                    foreach($tripTax['tcs'] as $tcs){
                        if($tcs['c_id'] == $tc->c_id){
                            if($tcs['tcs_per'] == 2){
                                $tc->cost = $tc->cost - $tcs['tcs'];
                            }else{
                                $tc->cost = $tc->cost + $tcs['tcs'];
                            }
                        }
                    }
                }
            }else{
                $packageC = [];
            }
            $result['package_c'] = $packageC;
            // C

            // advance payment
            if($data->payment_amt && $data->payment_date){
                $result['advance_payment'] = ['payment' =>$data->payment_amt, 'date'=> date("d M, y", strtotime($data->payment_date))];
            }else{
                $result['advance_payment'] = [];
            }
            // payment

            // part payment
            if(isset($data->part_payment_list)){
                $pp = json_decode($data->part_payment_list);
                foreach($pp as &$p){
                    $p->date = date("d M, Y", strtotime($p->date));
                }
                $result['part_payment'] = $pp ?? null;
            }else{
                $result['part_payment'] = [];
            }
            // payment


            // extra services redeemable
            if($data->trip_cost != null && $data->extra_services != null){
                $extraServices = json_decode($data->extra_services);
                $newExtraServices = [];
                foreach($extraServices as $es){
                    if(getExtraServiceByName($es->services) && getExtraServiceByName($es->services)->is_redeemable){
                        $es->traveler_name = getCustomerById($es->traveler)->name;
                        $es->extra_charges = $es->amount;
                        array_push($newExtraServices, $es);
                    }
                }
            }else{
                $newExtraServices = [];
            }
            $result['extra_services_redeemable'] = $newExtraServices;
            // extra services redeemable

            // points calc
            if($data->customer_id){
                $pointsArr = [];
                $actualTripCost = [];
                foreach(json_decode($data->customer_id) as $customer){
                    $actualCost = getTripCostWithoutTaxByBookingAndCustomerId($data->id, $customer);
                    
                    // actual trip cost
                    array_push($actualTripCost, ['traveler'=>getCustomerById($customer)->name ?? "Deleted", 'cost'=>$actualCost]);
                    // actual trip cost
                    
                    $cDataa = getCustomerById($customer)->parent;
                    $cTier = getPointPerByCustomerId($customer);
                    $points = ($actualCost * $cTier)/100;
                    // dd($points);
                    if($cDataa == 0 && !isset($pointsArr[$customer])){
                        array_push($pointsArr, [$customer => ['points'=>$points, 'name'=>getCustomerById($customer)->name, 'reward'=>$cTier]]);
                    }else{
                        if (array_key_exists($cDataa, $pointsArr[0])) {
                            $pointsArr[0][$cDataa]['points'] = $pointsArr[0][$cDataa]['points'] + $points;
                        }
                    }
                }
                // dd($actualTripCost);
                $result['points_list'] = $pointsArr;
                $result['actual_trip_cost'] = $actualTripCost;
                $result['real_trip_amt'] = $data->trip->price ?? "0";
            }
            
            return json_encode($result);
        }
    }  
}