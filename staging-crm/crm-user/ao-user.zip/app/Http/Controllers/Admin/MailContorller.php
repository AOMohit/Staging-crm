<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Mail\MailSystem;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail as FacadesMail;

class MailContorller extends Controller
{
    //
    public function index2($enquiry,$type)
    {
        
       if(isset($enquiry->customer_id)){
            $user = User::where('id', $enquiry->customer_id)->first();
        }
        // 
        
        if($type == 'registartion-user-mail'){
            $user = User::where('id', $enquiry->id)->first();
            // dd($user);
            $view = 'emails.user-registartion';
            $subject = 'Your documents are uploaded | Adventures Overland!';

            $mailData = [
                'first_name' => $user->first_name,
                'last_name' => $user->last_name,
                'email' => $user->email,

            ];
        }
        if ($type == 'registartion-mail') {
            
            $user = User::where('email', $enquiry['user_mail'])->first();
        
            $view = 'emails.registation-mail';
            $subject = 'Registration form data of'.$user->name.'for'. $enquiry['trip'] .' ! AO';
            $doc = ExtraDocuments::select('title','image','user_id')->where('user_id',$user->id)->get();
            $mailData = [
                'first_name' => $user->first_name,
                'last_name' => $user->last_name,
                'email' => $user->email,
                'gender' => $user->gender,
                'phone' => $user->phone,
                'profile' => url('storage/app/'.$user->profile),
                'address' => $user->address,
                'city' => $user->city,
                'country' => $user->country,
                'state' => $user->state,
                'pincode' => $user->pincode,
                'dob' => $user->dob,
                'meal_preference' => $user->meal_preference,
                'blood_group' => $user->blood_group,
                'profession' => $user->profession,
                'emg_contact' => $user->emg_contact,
                't_size' => $user->t_size,
                'medical_condition' => $user->medical_condition,
                'vaccination' => $user->vaccination,
                'tier' => $user->tier,
                'points' => $user->points,
                'referred_by' => $user->referred_by,
                'parent' => $user->parent,
                'relation' => $user->relation,
                'emg_name' => $user->emg_name,
                'something' => $user->something,
                'have_road_trip' => $user->have_road_trip,
                'thrilling_exp' => $user->thrilling_exp,
                'three_travel' => $user->three_travel,
                'three_place' => $user->three_place,
                'passport_front' => url('storage/app/' . $user->passport_front),
                'passport_back' => url('storage/app/' . $user->passport_back),
                'pan_gst' => url('storage/app/' . $user->pan_gst),  
                'driving' => url('storage/app/' . $user->driving),
                'letest_trip' => $user->letest_trip,
                'extra_doc'=> $doc
               
            ];
            return FacadesMail::to($enquiry['admin_email'])->send(new MailSystem($subject, $mailData, $view));
        }
        
        
        if($type == 'redeem'){

            $view = 'emails.redeem-email';
            $subject = 'Your points redeem inquery | Adventures Overland!';

            $mailData = [
                'first_name' => $user->first_name,
                'last_name' => $user->last_name,
                'email'=>$user->email,

            ];
        }
        if($type == 'trans-sender-mail'){
            $reciver_data = User::where('email',$enquiry->reciever_mail)->first();
            $view = 'emails.transfer-sender';
            $subject = 'Points Transferred Succefully to ' . $reciver_data->first_name. ' | Adventures Overland!';

            // dd($enquiry->reciever_mail);
            $mailData = [
                'first_name' => $user->first_name,
                'last_name' => $user->last_name,
                'points' => $enquiry->trans_amt,
               
                'reciver_email'=>$enquiry->reciever_mail,
                'email' => $user->email,
                
            ];
        }
        if ($type == 'trans-reciver-mail') {
            $reciver_data = User::where('email', $enquiry->reciever_mail)->first();
            $view = 'emails.transfer-reciver';
            $subject = 'You Recieved Points from '.$user->first_name.' | Adventures Overland!';

            // dd($enquiry->reciever_mail);
            $mailData = [
                'first_name' => $reciver_data->first_name,
                'last_name' => $reciver_data->last_name,
                'points' => $enquiry->trans_amt,

                'sender_mail' => $user->email,
                'email' => $reciver_data->email,

            ];
        }

        if($type == 'enquiry'){
            $view = 'emails.enquiry';
            $subject = 'Thanks for your enquiry | Adventures Overland!';
            $mailData = [
                'first_name' => $user->first_name,
                'last_name' => $user->last_name,
                'email' => $user->email,

            ];
        }


        // dd($mailData);
        if ($type == 'trans-reciver-mail') {
            FacadesMail::to($reciver_data->email)->send(new MailSystem($subject, $mailData, $view));

        }else{

            FacadesMail::to($user->email)->send(new MailSystem($subject,$mailData,$view));
        }

    }
}
